import {
  DiscoveryState,
  type DiscoveryStateValue,
} from '../../../domain/discovery/discovery-state';

import {
  ExplorationResultKind,
  type ExplorationLocatedResultKind,
} from '../../../domain/exploration/exploration-sector-result';

import {
  GalacticObjectScientificSubject,
} from '../../../domain/galactic-object/galactic-object-scientific-subject';

import {
  NebulaType,
  type NebulaType as NebulaTypeValue,
} from '../../../domain/galactic-object/nebula-type';

import {
  StarFormationActivity,
  type StarFormationActivity as StarFormationActivityValue,
} from '../../../domain/galactic-object/star-formation-activity';

import {
  SupernovaRemnantMorphology,
  type SupernovaRemnantMorphology as SupernovaRemnantMorphologyValue,
} from '../../../domain/galactic-object/supernova-remnant-morphology';

import {
  GalacticObjectLocator,
} from '../../../domain/generation/procedural-locator';

import {
  GeneratorVersion,
} from '../../../domain/generation/generator-version';

import {
  UniverseGenerationKey,
} from '../../../domain/generation/universe-generation-key';

import {
  UniverseSeed,
} from '../../../domain/universe/universe-seed';

import {
  HiiRegionGenerator,
} from '../../../simulation/galactic-object/hii-region-generator';

import {
  NebulaGenerator,
} from '../../../simulation/galactic-object/nebula-generator';

import {
  SupernovaRemnantGenerator,
} from '../../../simulation/galactic-object/supernova-remnant-generator';

import {
  ArchiveGalacticObjectCardAssembler,
  type ArchiveGalacticObjectCardModel,
} from '../../genesis-archive/archive-galactic-object-card';

import {
  HiiRegionLowRenderModelBuilder,
  type HiiRegionLowMorphologyFamily,
} from '../../genesis-archive/hii-region-low-render-model';

import {
  HiiRegionModerateRenderModelBuilder,
  type HiiRegionModerateMorphologyFamily,
} from '../../genesis-archive/hii-region-moderate-render-model';

import {
  HiiRegionHighRenderModelBuilder,
  type HiiRegionHighMorphologyFamily,
} from '../../genesis-archive/hii-region-high-render-model';

import {
  HiiRegionIntenseRenderModelBuilder,
  type HiiRegionIntenseMorphologyFamily,
} from '../../genesis-archive/hii-region-intense-render-model';

export const GalacticObjectLaboratoryGroup =
  Object.freeze({
    NEBULAE:
      'NEBULAE',

    HII:
      'HII',

    CLUSTERS:
      'CLUSTERS',

    SUPERNOVA_REMNANTS:
      'SUPERNOVA_REMNANTS',

    EXTREME:
      'EXTREME',
  } as const);

export type GalacticObjectLaboratoryGroup =
  typeof GalacticObjectLaboratoryGroup[
    keyof typeof GalacticObjectLaboratoryGroup
  ];

export const GalacticObjectLaboratoryCaseId =
  Object.freeze({
    NEBULA_EMISSION:
      'NEBULA_EMISSION',

    NEBULA_REFLECTION:
      'NEBULA_REFLECTION',

    NEBULA_DARK:
      'NEBULA_DARK',

    NEBULA_PLANETARY:
      'NEBULA_PLANETARY',

    HII_LOW:
      'HII_LOW',

    HII_MODERATE:
      'HII_MODERATE',

    HII_HIGH:
      'HII_HIGH',

    HII_INTENSE:
      'HII_INTENSE',

    OPEN_CLUSTER:
      'OPEN_CLUSTER',

    GLOBULAR_CLUSTER:
      'GLOBULAR_CLUSTER',

    SNR_SHELL:
      'SNR_SHELL',

    SNR_PLERION:
      'SNR_PLERION',

    SNR_COMPOSITE:
      'SNR_COMPOSITE',

    RESERVED_EXTREME:
      'RESERVED_EXTREME',
  } as const);

export type GalacticObjectLaboratoryCaseId =
  typeof GalacticObjectLaboratoryCaseId[
    keyof typeof GalacticObjectLaboratoryCaseId
  ];

export interface GalacticObjectLaboratoryCase {
  readonly id:
    GalacticObjectLaboratoryCaseId;

  readonly group:
    GalacticObjectLaboratoryGroup;

  readonly label:
    string;

  readonly familyLabel:
    string;

  readonly locator:
    GalacticObjectLocator;

  readonly resultKind:
    ExplorationLocatedResultKind;

  readonly expectedSubject:
    GalacticObjectScientificSubject | null;

  readonly expectedNebulaType:
    NebulaTypeValue | null;

  readonly expectedHiiActivity:
    StarFormationActivityValue | null;

  readonly expectedRemnantMorphology:
    SupernovaRemnantMorphologyValue | null;

  readonly description:
    string;
}

export interface GalacticObjectLaboratoryState {
  readonly state:
    DiscoveryStateValue;

  readonly label:
    string;

  readonly shortLabel:
    string;
}

export interface GalacticObjectLaboratoryFrame {
  readonly state:
    GalacticObjectLaboratoryState;

  readonly card:
    ArchiveGalacticObjectCardModel;
}

export interface EmissionNebulaLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface ReflectionNebulaLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface DarkNebulaLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface PlanetaryNebulaLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface HiiLowLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface HiiModerateLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface HiiHighLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export interface HiiIntenseLaboratorySample {
  readonly index:
    number;

  readonly label:
    string;

  readonly locator:
    GalacticObjectLocator;
}

export const GALACTIC_OBJECT_LABORATORY_STATES:
  readonly GalacticObjectLaboratoryState[] =
  Object.freeze([
    Object.freeze({
      state:
        DiscoveryState.DETECTED,
      label:
        'Detectado',
      shortLabel:
        'DETECTED',
    }),
    Object.freeze({
      state:
        DiscoveryState.DISCOVERED,
      label:
        'Descubierto',
      shortLabel:
        'DISCOVERED',
    }),
    Object.freeze({
      state:
        DiscoveryState.CATALOGUED,
      label:
        'Catalogado',
      shortLabel:
        'CATALOGUED',
    }),
    Object.freeze({
      state:
        DiscoveryState.CONFIRMED,
      label:
        'Confirmado',
      shortLabel:
        'CONFIRMED',
    }),
  ]);

const GENERATION_KEY =
  new UniverseGenerationKey(
    UniverseSeed.parse(
      '7F21-A9D4-18CE-4B70-92F1-6A0C-6E35-D8B1',
    ),
    GeneratorVersion.V1,
  );

const NEBULA_SECTOR_KEY =
  123456789n;

const EMISSION_NEBULA_SAMPLE_COUNT =
  8;

const REFLECTION_NEBULA_SAMPLE_COUNT =
  8;

const DARK_NEBULA_SAMPLE_COUNT =
  8;

const PLANETARY_NEBULA_SAMPLE_COUNT =
  8;

const HII_LOW_SAMPLE_COUNT =
  8;

const HII_MODERATE_SAMPLE_COUNT =
  8;

const HII_HIGH_SAMPLE_COUNT =
  8;

const HII_INTENSE_SAMPLE_COUNT =
  8;

let cachedEmissionNebulaSamples:
  readonly EmissionNebulaLaboratorySample[] | null =
    null;

let cachedReflectionNebulaSamples:
  readonly ReflectionNebulaLaboratorySample[] | null =
    null;

let cachedDarkNebulaSamples:
  readonly DarkNebulaLaboratorySample[] | null =
    null;

let cachedPlanetaryNebulaSamples:
  readonly PlanetaryNebulaLaboratorySample[] | null =
    null;

let cachedHiiLowSamples:
  readonly HiiLowLaboratorySample[] | null =
    null;

let cachedHiiModerateSamples:
  readonly HiiModerateLaboratorySample[] | null =
    null;

let cachedHiiHighSamples:
  readonly HiiHighLaboratorySample[] | null =
    null;

let cachedHiiIntenseSamples:
  readonly HiiIntenseLaboratorySample[] | null =
    null;

let cachedHiiRepresentatives:
  ReadonlyMap<
    StarFormationActivityValue,
    GalacticObjectLocator
  > | null =
    null;

let cachedRemnantRepresentatives:
  ReadonlyMap<
    SupernovaRemnantMorphologyValue,
    GalacticObjectLocator
  > | null =
    null;

export const GALACTIC_OBJECT_LABORATORY_CASES:
  readonly GalacticObjectLaboratoryCase[] =
  Object.freeze(
    buildCasesV1(),
  );

export class GalacticObjectLaboratoryFixtures {

  private constructor() {}

  static emissionNebulaSamples():
    readonly EmissionNebulaLaboratorySample[] {

    if (
      cachedEmissionNebulaSamples !==
        null
    ) {
      return cachedEmissionNebulaSamples;
    }

    cachedEmissionNebulaSamples =
      Object.freeze(
        buildEmissionNebulaSamplesV1(),
      );

    return cachedEmissionNebulaSamples;
  }

  static reflectionNebulaSamples():
    readonly ReflectionNebulaLaboratorySample[] {

    if (
      cachedReflectionNebulaSamples !==
        null
    ) {
      return cachedReflectionNebulaSamples;
    }

    cachedReflectionNebulaSamples =
      Object.freeze(
        buildReflectionNebulaSamplesV1(),
      );

    return cachedReflectionNebulaSamples;
  }

  static darkNebulaSamples():
    readonly DarkNebulaLaboratorySample[] {

    if (
      cachedDarkNebulaSamples !==
        null
    ) {
      return cachedDarkNebulaSamples;
    }

    cachedDarkNebulaSamples =
      Object.freeze(
        buildDarkNebulaSamplesV1(),
      );

    return cachedDarkNebulaSamples;
  }

  static planetaryNebulaSamples():
    readonly PlanetaryNebulaLaboratorySample[] {

    if (
      cachedPlanetaryNebulaSamples !==
        null
    ) {
      return cachedPlanetaryNebulaSamples;
    }

    cachedPlanetaryNebulaSamples =
      Object.freeze(
        buildPlanetaryNebulaSamplesV1(),
      );

    return cachedPlanetaryNebulaSamples;
  }

  static hiiLowSamples():
    readonly HiiLowLaboratorySample[] {

    if (
      cachedHiiLowSamples !==
        null
    ) {
      return cachedHiiLowSamples;
    }

    cachedHiiLowSamples =
      Object.freeze(
        buildHiiLowSamplesV1(),
      );

    return cachedHiiLowSamples;
  }

  static hiiModerateSamples():
    readonly HiiModerateLaboratorySample[] {

    if (
      cachedHiiModerateSamples !==
        null
    ) {
      return cachedHiiModerateSamples;
    }

    cachedHiiModerateSamples =
      Object.freeze(
        buildHiiModerateSamplesV1(),
      );

    return cachedHiiModerateSamples;
  }

  static hiiHighSamples():
    readonly HiiHighLaboratorySample[] {

    if (
      cachedHiiHighSamples !==
        null
    ) {
      return cachedHiiHighSamples;
    }

    cachedHiiHighSamples =
      Object.freeze(
        buildHiiHighSamplesV1(),
      );

    return cachedHiiHighSamples;
  }

  static hiiIntenseSamples():
    readonly HiiIntenseLaboratorySample[] {

    if (
      cachedHiiIntenseSamples !==
        null
    ) {
      return cachedHiiIntenseSamples;
    }

    cachedHiiIntenseSamples =
      Object.freeze(
        buildHiiIntenseSamplesV1(),
      );

    return cachedHiiIntenseSamples;
  }

  static caseDefinition(
    caseId:
      GalacticObjectLaboratoryCaseId,

    emissionSampleIndex =
      0,

    reflectionSampleIndex =
      0,

    darkSampleIndex =
      0,

    planetarySampleIndex =
      0,

    hiiLowSampleIndex =
      0,

    hiiModerateSampleIndex =
      0,

    hiiHighSampleIndex =
      0,

    hiiIntenseSampleIndex =
      0,
  ): GalacticObjectLaboratoryCase {

    const caseDefinition =
      GALACTIC_OBJECT_LABORATORY_CASES
        .find(
          candidate =>
            candidate.id ===
            caseId,
        );

    if (
      caseDefinition ===
        undefined
    ) {
      throw new RangeError(
        `Unsupported GalacticObject laboratory case: ${String(caseId)}.`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .NEBULA_EMISSION
    ) {
      const sample =
        this
          .emissionNebulaSamples()[
            emissionSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported emission-nebula laboratory sample index: ${emissionSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .NEBULA_REFLECTION
    ) {
      const sample =
        this
          .reflectionNebulaSamples()[
            reflectionSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported reflection-nebula laboratory sample index: ${reflectionSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .NEBULA_DARK
    ) {
      const sample =
        this
          .darkNebulaSamples()[
            darkSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported dark-nebula laboratory sample index: ${darkSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .NEBULA_PLANETARY
    ) {
      const sample =
        this
          .planetaryNebulaSamples()[
            planetarySampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported planetary-nebula laboratory sample index: ${planetarySampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .HII_LOW
    ) {
      const sample =
        this
          .hiiLowSamples()[
            hiiLowSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported LOW H II laboratory sample index: ${hiiLowSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .HII_MODERATE
    ) {
      const sample =
        this
          .hiiModerateSamples()[
            hiiModerateSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported MODERATE H II laboratory sample index: ${hiiModerateSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .HII_HIGH
    ) {
      const sample =
        this
          .hiiHighSamples()[
            hiiHighSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported HIGH H II laboratory sample index: ${hiiHighSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    if (
      caseId ===
        GalacticObjectLaboratoryCaseId
          .HII_INTENSE
    ) {
      const sample =
        this
          .hiiIntenseSamples()[
            hiiIntenseSampleIndex
          ];

      if (
        sample ===
          undefined
      ) {
        throw new RangeError(
          `Unsupported INTENSE H II laboratory sample index: ${hiiIntenseSampleIndex}.`,
        );
      }

      return caseOf(
        caseDefinition.id,
        caseDefinition.group,
        caseDefinition.label,
        caseDefinition.familyLabel,
        sample.locator,
        caseDefinition.resultKind,
        caseDefinition.expectedSubject,
        caseDefinition.expectedNebulaType,
        caseDefinition.expectedHiiActivity,
        caseDefinition.expectedRemnantMorphology,
        `Muestra ${sample.label} · ${caseDefinition.description}`,
      );
    }

    return caseDefinition;
  }

  static frames(
    caseId:
      GalacticObjectLaboratoryCaseId,

    emissionSampleIndex =
      0,

    reflectionSampleIndex =
      0,

    darkSampleIndex =
      0,

    planetarySampleIndex =
      0,

    hiiLowSampleIndex =
      0,

    hiiModerateSampleIndex =
      0,

    hiiHighSampleIndex =
      0,

    hiiIntenseSampleIndex =
      0,
  ): readonly GalacticObjectLaboratoryFrame[] {

    const caseDefinition =
      this.caseDefinition(
        caseId,
        emissionSampleIndex,
        reflectionSampleIndex,
        darkSampleIndex,
        planetarySampleIndex,
        hiiLowSampleIndex,
        hiiModerateSampleIndex,
        hiiHighSampleIndex,
        hiiIntenseSampleIndex,
      );

    return Object.freeze(
      GALACTIC_OBJECT_LABORATORY_STATES
        .map(
          state =>
            Object.freeze({
              state,
              card:
                ArchiveGalacticObjectCardAssembler
                  .build(
                    GENERATION_KEY,
                    caseDefinition
                      .locator,
                    caseDefinition
                      .resultKind,
                    state.state,
                  ),
            }),
        ),
    );
  }
}

function buildHiiModerateSamplesV1():
  HiiModerateLaboratorySample[] {

  const primary =
    hiiRepresentativesV1()
      .get(
        StarFormationActivity
          .MODERATE,
      );

  if (
    primary ===
      undefined
  ) {
    throw new RangeError(
      'Missing canonical V1 MODERATE H II representative.',
    );
  }

  const primaryMorphology =
    hiiModerateMorphologyFamilyV1(
      primary,
    );

  const selected =
    new Map<
      HiiRegionModerateMorphologyFamily,
      GalacticObjectLocator
    >();

  selected.set(
    primaryMorphology,
    primary,
  );

  for (
    let index =
      0n;
    index <
      65_536n &&
    selected.size <
      HII_MODERATE_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary.galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      HiiRegionGenerator
        .resolveActivity(
          GENERATION_KEY,
          locator,
        ) !==
      StarFormationActivity
        .MODERATE
    ) {
      continue;
    }

    const morphology =
      hiiModerateMorphologyFamilyV1(
        locator,
      );

    if (
      selected.has(
        morphology,
      )
    ) {
      continue;
    }

    selected.set(
      morphology,
      locator,
    );
  }

  if (
    selected.size !==
      HII_MODERATE_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The visual laboratory found ${selected.size}/${HII_MODERATE_SAMPLE_COUNT} distinct MODERATE H II morphology families.`,
    );
  }

  const orderedLocators =
    [
      primary,
      ...Array.from(
        selected.values(),
      ).filter(
        locator =>
          locator.galacticObjectIndex !==
          primary.galacticObjectIndex,
      ),
    ];

  return orderedLocators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function hiiModerateMorphologyFamilyV1(
  locator:
    GalacticObjectLocator,
): HiiRegionModerateMorphologyFamily {

  const confirmed =
    ArchiveGalacticObjectCardAssembler
      .build(
        GENERATION_KEY,
        locator,
        ExplorationResultKind.NEBULA,
        DiscoveryState.CONFIRMED,
      );

  return HiiRegionModerateRenderModelBuilder
    .build(
      confirmed.render,
    )
    .morphologyFamily;
}

function buildHiiHighSamplesV1():
  HiiHighLaboratorySample[] {

  const primary =
    hiiRepresentativesV1()
      .get(
        StarFormationActivity
          .HIGH,
      );

  if (
    primary ===
      undefined
  ) {
    throw new RangeError(
      'Missing canonical V1 HIGH H II representative.',
    );
  }

  const primaryMorphology =
    hiiHighMorphologyFamilyV1(
      primary,
    );

  const selected =
    new Map<
      HiiRegionHighMorphologyFamily,
      GalacticObjectLocator
    >();

  selected.set(
    primaryMorphology,
    primary,
  );

  for (
    let index =
      0n;
    index <
      65_536n &&
    selected.size <
      HII_HIGH_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary.galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      HiiRegionGenerator
        .resolveActivity(
          GENERATION_KEY,
          locator,
        ) !==
      StarFormationActivity
        .HIGH
    ) {
      continue;
    }

    const morphology =
      hiiHighMorphologyFamilyV1(
        locator,
      );

    if (
      selected.has(
        morphology,
      )
    ) {
      continue;
    }

    selected.set(
      morphology,
      locator,
    );
  }

  if (
    selected.size !==
      HII_HIGH_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The visual laboratory found ${selected.size}/${HII_HIGH_SAMPLE_COUNT} distinct HIGH H II morphology families.`,
    );
  }

  const orderedLocators =
    [
      primary,
      ...Array.from(
        selected.values(),
      ).filter(
        locator =>
          locator.galacticObjectIndex !==
          primary.galacticObjectIndex,
      ),
    ];

  return orderedLocators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function hiiHighMorphologyFamilyV1(
  locator:
    GalacticObjectLocator,
): HiiRegionHighMorphologyFamily {

  const confirmed =
    ArchiveGalacticObjectCardAssembler
      .build(
        GENERATION_KEY,
        locator,
        ExplorationResultKind.NEBULA,
        DiscoveryState.CONFIRMED,
      );

  return HiiRegionHighRenderModelBuilder
    .build(
      confirmed.render,
    )
    .morphologyFamily;
}

function buildHiiIntenseSamplesV1():
  HiiIntenseLaboratorySample[] {

  const primary =
    hiiRepresentativesV1()
      .get(
        StarFormationActivity
          .INTENSE,
      );

  if (
    primary ===
      undefined
  ) {
    throw new RangeError(
      'Missing canonical V1 INTENSE H II representative.',
    );
  }

  const primaryMorphology =
    hiiIntenseMorphologyFamilyV1(
      primary,
    );

  const selected =
    new Map<
      HiiRegionIntenseMorphologyFamily,
      GalacticObjectLocator
    >();

  selected.set(
    primaryMorphology,
    primary,
  );

  for (
    let index =
      0n;
    index <
      65_536n &&
    selected.size <
      HII_INTENSE_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary.galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      HiiRegionGenerator
        .resolveActivity(
          GENERATION_KEY,
          locator,
        ) !==
      StarFormationActivity
        .INTENSE
    ) {
      continue;
    }

    const morphology =
      hiiIntenseMorphologyFamilyV1(
        locator,
      );

    if (
      selected.has(
        morphology,
      )
    ) {
      continue;
    }

    selected.set(
      morphology,
      locator,
    );
  }

  if (
    selected.size !==
      HII_INTENSE_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The visual laboratory found ${selected.size}/${HII_INTENSE_SAMPLE_COUNT} distinct INTENSE H II morphology families.`,
    );
  }

  const orderedLocators =
    [
      primary,
      ...Array.from(
        selected.values(),
      ).filter(
        locator =>
          locator.galacticObjectIndex !==
          primary.galacticObjectIndex,
      ),
    ];

  return orderedLocators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function hiiIntenseMorphologyFamilyV1(
  locator:
    GalacticObjectLocator,
): HiiRegionIntenseMorphologyFamily {

  const confirmed =
    ArchiveGalacticObjectCardAssembler
      .build(
        GENERATION_KEY,
        locator,
        ExplorationResultKind.NEBULA,
        DiscoveryState.CONFIRMED,
      );

  return HiiRegionIntenseRenderModelBuilder
    .build(
      confirmed.render,
    )
    .morphologyFamily;
}

function buildHiiLowSamplesV1():
  HiiLowLaboratorySample[] {

  const primary =
    hiiRepresentativesV1()
      .get(
        StarFormationActivity
          .LOW,
      );

  if (
    primary ===
      undefined
  ) {
    throw new RangeError(
      'Missing canonical V1 LOW H II representative.',
    );
  }

  const primaryMorphology =
    hiiLowMorphologyFamilyV2(
      primary,
    );

  const lockedFamilies =
    new Set<
      HiiRegionLowMorphologyFamily
    >([
      primaryMorphology,
    ]);

  const bestByFamily =
    new Map<
      HiiRegionLowMorphologyFamily,
      {
        readonly locator:
          GalacticObjectLocator;

        readonly score:
          number;
      }
    >();

  /*
   * V2.2 laboratory refinement: preserve the canonical LOW representative as A
   * and still guarantee one sample per morphology family, but do not stop at
   * the first hit. Search a deterministic real LOW-only window and keep the
   * strongest visual representative found for each remaining family. This keeps
   * the scientific grounding intact while separating families more clearly in
   * the A..H comparison grid.
   */
  for (
    let index =
      0n;
    index <
      65_536n;
    index +=
      1n
  ) {
    if (
      index ===
        primary.galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      HiiRegionGenerator
        .resolveActivity(
          GENERATION_KEY,
          locator,
        ) !==
      StarFormationActivity
        .LOW
    ) {
      continue;
    }

    const model =
      hiiLowRenderModelV2(
        locator,
      );

    const morphology =
      model.morphologyFamily;

    if (
      lockedFamilies.has(
        morphology,
      )
    ) {
      continue;
    }

    const score =
      hiiLowRepresentativeScoreV2(
        model,
      );

    const currentBest =
      bestByFamily.get(
        morphology,
      );

    if (
      currentBest ===
        undefined ||
      score >
        currentBest.score
    ) {
      bestByFamily.set(
        morphology,
        Object.freeze({
          locator,
          score,
        }),
      );
    }
  }

  const orderedFamilies =
    allHiiLowMorphologyFamiliesV2()
      .filter(
        family =>
          family !==
          primaryMorphology,
      );

  const orderedLocators =
    [
      primary,
      ...orderedFamilies.map(
        family => {
          const candidate =
            bestByFamily.get(
              family,
            );

          if (
            candidate ===
              undefined
          ) {
            throw new RangeError(
              `The V2.2 visual laboratory could not find a representative for LOW H II morphology family ${family}.`,
            );
          }

          return candidate.locator;
        },
      ),
    ];

  if (
    orderedLocators.length !==
      HII_LOW_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The V2.2 visual laboratory found ${orderedLocators.length}/${HII_LOW_SAMPLE_COUNT} LOW H II morphology representatives.`,
    );
  }

  return orderedLocators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function hiiLowMorphologyFamilyV2(
  locator:
    GalacticObjectLocator,
): HiiRegionLowMorphologyFamily {

  return hiiLowRenderModelV2(
    locator,
  )
    .morphologyFamily;
}

function hiiLowRenderModelV2(
  locator:
    GalacticObjectLocator,
) {

  const confirmed =
    ArchiveGalacticObjectCardAssembler
      .build(
        GENERATION_KEY,
        locator,
        ExplorationResultKind.NEBULA,
        DiscoveryState.CONFIRMED,
      );

  return HiiRegionLowRenderModelBuilder
    .build(
      confirmed.render,
    );
}

function allHiiLowMorphologyFamiliesV2():
  readonly HiiRegionLowMorphologyFamily[] {

  return Object.freeze([
    'BUBBLE',
    'BLISTER',
    'CLUMPY',
    'COMPACT',
    'PILLARS',
    'FILAMENTARY',
    'DOUBLE',
    'BROKEN_SHELL',
  ]);
}

function hiiLowRepresentativeScoreV2(
  model:
    ReturnType<
      typeof HiiRegionLowRenderModelBuilder.build
    >,
): number {

  const common =
    model.apparentExtent *
      0.60 +
    model.volumeDepth *
      0.30 +
    model.edgeSharpness *
      0.40 +
    model.paletteAccent *
      0.18 +
    model.chromaGain *
      0.12;

  switch (
    model.morphologyFamily
  ) {
    case 'BUBBLE':
      return common +
        model.shellStrength *
          1.50 +
        model.cavityStrength *
          0.90 +
        model.cavityRadius *
          0.80 -
        model.asymmetryStrength *
          0.22;

    case 'BLISTER':
      return common +
        model.asymmetryStrength *
          1.40 +
        model.sourceSpread *
          1.10 +
        model.edgeSharpness *
          0.50 +
        model.pillarStrength *
          0.20;

    case 'CLUMPY':
      return common +
        model.morphologyNoiseScale *
          1.15 +
        model.asymmetryStrength *
          0.60 +
        model.sourceSpread *
          0.40;

    case 'COMPACT':
      return common +
        (
          1.20 -
          model.apparentExtent
        ) *
          1.20 +
        model.concentration *
          0.70 +
        model.edgeSharpness *
          0.30;

    case 'PILLARS':
      return common +
        model.pillarStrength *
          1.80 +
        model.dustLaneStrength *
          0.95 +
        model.asymmetryStrength *
          0.30;

    case 'FILAMENTARY':
      return common +
        model.structureAspect *
          1.20 +
        model.morphologyNoiseScale *
          0.90 +
        model.edgeSharpness *
          0.45;

    case 'DOUBLE':
      return common +
        model.lobeStrength *
          1.85 +
        model.sourceSpread *
          0.80 +
        model.apparentExtent *
          0.25;

    case 'BROKEN_SHELL':
      return common +
        model.shellStrength *
          1.30 +
        model.asymmetryStrength *
          1.00 +
        model.cavityRadius *
          0.60;
  }
}

function buildEmissionNebulaSamplesV1():
  EmissionNebulaLaboratorySample[] {

  const locators:
    GalacticObjectLocator[] =
    [];

  /*
   * Preserve the already-validated O17 representative as sample A.
   */
  const primary =
    new GalacticObjectLocator(
      0n,
      NEBULA_SECTOR_KEY,
      17n,
    );

  requireEmissionNebulaV1(
    primary,
  );

  locators.push(
    primary,
  );

  for (
    let index =
      0n;
    index <
      4_096n &&
    locators.length <
      EMISSION_NEBULA_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary
          .galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    /*
     * GalacticObject indices are partitioned first by the canonical point-9.4
     * coarse family. Never ask NebulaGenerator to materialize a locator that
     * belongs to STAR_CLUSTER or EXTREME_OBJECT.
     */
    if (
      !NebulaGenerator
        .isNebulaLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const nebula =
      NebulaGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      nebula.nebulaType !==
        NebulaType.EMISSION
    ) {
      continue;
    }

    if (
      HiiRegionGenerator
        .isHiiRegionLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    locators.push(
      locator,
    );
  }

  if (
    locators.length !==
    EMISSION_NEBULA_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The canonical V1 laboratory sample found ${locators.length}/${EMISSION_NEBULA_SAMPLE_COUNT} non-HII emission nebulae.`,
    );
  }

  return locators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function buildPlanetaryNebulaSamplesV1():
  PlanetaryNebulaLaboratorySample[] {

  const locators:
    GalacticObjectLocator[] =
    [];

  /*
   * Preserve the already-frozen PLANETARY laboratory representative as A.
   */
  const primary =
    new GalacticObjectLocator(
      0n,
      NEBULA_SECTOR_KEY,
      10n,
    );

  requirePlanetaryNebulaV1(
    primary,
  );

  locators.push(
    primary,
  );

  for (
    let index =
      0n;
    index <
      4_096n &&
    locators.length <
      PLANETARY_NEBULA_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary
          .galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      !NebulaGenerator
        .isNebulaLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const nebula =
      NebulaGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      nebula.nebulaType !==
        NebulaType.PLANETARY
    ) {
      continue;
    }

    locators.push(
      locator,
    );
  }

  if (
    locators.length !==
    PLANETARY_NEBULA_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The canonical V1 laboratory sample found ${locators.length}/${PLANETARY_NEBULA_SAMPLE_COUNT} planetary nebulae.`,
    );
  }

  return locators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function requirePlanetaryNebulaV1(
  locator:
    GalacticObjectLocator,
): void {

  if (
    !NebulaGenerator
      .isNebulaLocator(
        GENERATION_KEY,
        locator,
      )
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} no longer belongs to the NEBULA family.`,
    );
  }

  const nebula =
    NebulaGenerator
      .generate(
        GENERATION_KEY,
        locator,
      );

  if (
    nebula.nebulaType !==
      NebulaType.PLANETARY
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} is no longer a planetary nebula.`,
    );
  }
}

function buildDarkNebulaSamplesV1():
  DarkNebulaLaboratorySample[] {

  const locators:
    GalacticObjectLocator[] =
    [];

  const primary =
    new GalacticObjectLocator(
      0n,
      NEBULA_SECTOR_KEY,
      16n,
    );

  requireDarkNebulaV1(
    primary,
  );

  locators.push(
    primary,
  );

  for (
    let index =
      0n;
    index <
      4_096n &&
    locators.length <
      DARK_NEBULA_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary
          .galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      !NebulaGenerator
        .isNebulaLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const nebula =
      NebulaGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      nebula.nebulaType !==
        NebulaType.DARK
    ) {
      continue;
    }

    locators.push(
      locator,
    );
  }

  if (
    locators.length !==
    DARK_NEBULA_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The canonical V1 laboratory sample found ${locators.length}/${DARK_NEBULA_SAMPLE_COUNT} dark nebulae.`,
    );
  }

  return locators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function requireDarkNebulaV1(
  locator:
    GalacticObjectLocator,
): void {

  if (
    !NebulaGenerator
      .isNebulaLocator(
        GENERATION_KEY,
        locator,
      )
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} no longer belongs to the NEBULA family.`,
    );
  }

  const nebula =
    NebulaGenerator
      .generate(
        GENERATION_KEY,
        locator,
      );

  if (
    nebula.nebulaType !==
      NebulaType.DARK
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} is no longer a dark nebula.`,
    );
  }
}

function buildReflectionNebulaSamplesV1():
  ReflectionNebulaLaboratorySample[] {

  const locators:
    GalacticObjectLocator[] =
    [];

  const primary =
    new GalacticObjectLocator(
      0n,
      NEBULA_SECTOR_KEY,
      8n,
    );

  requireReflectionNebulaV1(
    primary,
  );

  locators.push(
    primary,
  );

  for (
    let index =
      0n;
    index <
      4_096n &&
    locators.length <
      REFLECTION_NEBULA_SAMPLE_COUNT;
    index +=
      1n
  ) {
    if (
      index ===
        primary
          .galacticObjectIndex
    ) {
      continue;
    }

    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      !NebulaGenerator
        .isNebulaLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const nebula =
      NebulaGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      nebula.nebulaType !==
        NebulaType.REFLECTION
    ) {
      continue;
    }

    locators.push(
      locator,
    );
  }

  if (
    locators.length !==
    REFLECTION_NEBULA_SAMPLE_COUNT
  ) {
    throw new RangeError(
      `The canonical V1 laboratory sample found ${locators.length}/${REFLECTION_NEBULA_SAMPLE_COUNT} reflection nebulae.`,
    );
  }

  return locators.map(
    (
      locator,
      index,
    ) =>
      Object.freeze({
        index,
        label:
          String.fromCharCode(
            65 +
            index,
          ),
        locator,
      }),
  );
}

function requireReflectionNebulaV1(
  locator:
    GalacticObjectLocator,
): void {

  if (
    !NebulaGenerator
      .isNebulaLocator(
        GENERATION_KEY,
        locator,
      )
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} no longer belongs to the NEBULA family.`,
    );
  }

  const nebula =
    NebulaGenerator
      .generate(
        GENERATION_KEY,
        locator,
      );

  if (
    nebula.nebulaType !==
      NebulaType.REFLECTION
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} is no longer a reflection nebula.`,
    );
  }
}

function requireEmissionNebulaV1(
  locator:
    GalacticObjectLocator,
): void {

  const nebula =
    NebulaGenerator
      .generate(
        GENERATION_KEY,
        locator,
      );

  if (
    nebula.nebulaType !==
      NebulaType.EMISSION ||
    HiiRegionGenerator
      .isHiiRegionLocator(
        GENERATION_KEY,
        locator,
      )
  ) {
    throw new RangeError(
      `Frozen locator O${locator.galacticObjectIndex} is no longer a non-HII emission nebula.`,
    );
  }
}

function buildCasesV1():
  GalacticObjectLaboratoryCase[] {

  const hii =
    hiiRepresentativesV1();

  const remnants =
    remnantRepresentativesV1();

  return [
    caseOf(
      GalacticObjectLaboratoryCaseId.NEBULA_EMISSION,
      GalacticObjectLaboratoryGroup.NEBULAE,
      'Nebulosa de emisión',
      'Nebulosa',
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        17n,
      ),
      ExplorationResultKind.NEBULA,
      GalacticObjectScientificSubject.NEBULA,
      NebulaType.EMISSION,
      null,
      null,
      'Nebulosa de emisión V1 que no cae en la especialización H II.',
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.NEBULA_REFLECTION,
      GalacticObjectLaboratoryGroup.NEBULAE,
      'Nebulosa de reflexión',
      'Nebulosa',
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        8n,
      ),
      ExplorationResultKind.NEBULA,
      GalacticObjectScientificSubject.NEBULA,
      NebulaType.REFLECTION,
      null,
      null,
      'Nebulosa de reflexión V1 con polvo y gas iluminados por fuentes estelares.',
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.NEBULA_DARK,
      GalacticObjectLaboratoryGroup.NEBULAE,
      'Nebulosa oscura',
      'Nebulosa',
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        16n,
      ),
      ExplorationResultKind.NEBULA,
      GalacticObjectScientificSubject.NEBULA,
      NebulaType.DARK,
      null,
      null,
      'Nebulosa oscura V1 con alta presencia de polvo y baja ionización.',
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.NEBULA_PLANETARY,
      GalacticObjectLaboratoryGroup.NEBULAE,
      'Nebulosa planetaria',
      'Nebulosa',
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        10n,
      ),
      ExplorationResultKind.NEBULA,
      GalacticObjectScientificSubject.NEBULA,
      NebulaType.PLANETARY,
      null,
      null,
      'Nebulosa planetaria V1 como envoltura gaseosa compacta.',
    ),
    hiiCase(
      GalacticObjectLaboratoryCaseId.HII_LOW,
      'Región H II · baja',
      StarFormationActivity.LOW,
      hii,
    ),
    hiiCase(
      GalacticObjectLaboratoryCaseId.HII_MODERATE,
      'Región H II · moderada',
      StarFormationActivity.MODERATE,
      hii,
    ),
    hiiCase(
      GalacticObjectLaboratoryCaseId.HII_HIGH,
      'Región H II · alta',
      StarFormationActivity.HIGH,
      hii,
    ),
    hiiCase(
      GalacticObjectLaboratoryCaseId.HII_INTENSE,
      'Región H II · intensa',
      StarFormationActivity.INTENSE,
      hii,
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.OPEN_CLUSTER,
      GalacticObjectLaboratoryGroup.CLUSTERS,
      'Cúmulo abierto',
      'Cúmulo estelar',
      new GalacticObjectLocator(
        0n,
        0n,
        2n,
      ),
      ExplorationResultKind.STAR_CLUSTER,
      GalacticObjectScientificSubject.OPEN_CLUSTER,
      null,
      null,
      null,
      'Cúmulo abierto V1 con población estelar dispersa.',
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.GLOBULAR_CLUSTER,
      GalacticObjectLaboratoryGroup.CLUSTERS,
      'Cúmulo globular',
      'Cúmulo estelar',
      new GalacticObjectLocator(
        0n,
        0n,
        7n,
      ),
      ExplorationResultKind.STAR_CLUSTER,
      GalacticObjectScientificSubject.GLOBULAR_CLUSTER,
      null,
      null,
      null,
      'Cúmulo globular V1 de alta concentración central.',
    ),
    remnantCase(
      GalacticObjectLaboratoryCaseId.SNR_SHELL,
      'Remanente SN · cáscara',
      SupernovaRemnantMorphology.SHELL,
      remnants,
    ),
    remnantCase(
      GalacticObjectLaboratoryCaseId.SNR_PLERION,
      'Remanente SN · plerión',
      SupernovaRemnantMorphology.PLERION,
      remnants,
    ),
    remnantCase(
      GalacticObjectLaboratoryCaseId.SNR_COMPOSITE,
      'Remanente SN · compuesto',
      SupernovaRemnantMorphology.COMPOSITE,
      remnants,
    ),
    caseOf(
      GalacticObjectLaboratoryCaseId.RESERVED_EXTREME,
      GalacticObjectLaboratoryGroup.EXTREME,
      'Objeto extremo reservado',
      'Fuente extrema',
      new GalacticObjectLocator(
        0n,
        0n,
        18n,
      ),
      ExplorationResultKind.EXTREME_OBJECT,
      null,
      null,
      null,
      null,
      'Complemento EXTREME_OBJECT deliberadamente sin especialización física V1.',
    ),
  ];
}

function caseOf(
  id:
    GalacticObjectLaboratoryCaseId,

  group:
    GalacticObjectLaboratoryGroup,

  label:
    string,

  familyLabel:
    string,

  locator:
    GalacticObjectLocator,

  resultKind:
    ExplorationLocatedResultKind,

  expectedSubject:
    GalacticObjectScientificSubject | null,

  expectedNebulaType:
    NebulaTypeValue | null,

  expectedHiiActivity:
    StarFormationActivityValue | null,

  expectedRemnantMorphology:
    SupernovaRemnantMorphologyValue | null,

  description:
    string,
): GalacticObjectLaboratoryCase {

  return Object.freeze({
    id,
    group,
    label,
    familyLabel,
    locator,
    resultKind,
    expectedSubject,
    expectedNebulaType,
    expectedHiiActivity,
    expectedRemnantMorphology,
    description,
  });
}

function hiiCase(
  id:
    GalacticObjectLaboratoryCaseId,

  label:
    string,

  activity:
    StarFormationActivityValue,

  representatives:
    ReadonlyMap<
      StarFormationActivityValue,
      GalacticObjectLocator
    >,
): GalacticObjectLaboratoryCase {

  const locator =
    representatives.get(
      activity,
    );

  if (
    locator ===
      undefined
  ) {
    throw new RangeError(
      `Missing V1 H II laboratory representative for ${activity}.`,
    );
  }

  return caseOf(
    id,
    GalacticObjectLaboratoryGroup.HII,
    label,
    'Región H II',
    locator,
    ExplorationResultKind.NEBULA,
    GalacticObjectScientificSubject.HII_REGION,
    NebulaType.EMISSION,
    activity,
    null,
    `Región H II V1 con actividad de formación estelar ${activity}.`,
  );
}

function remnantCase(
  id:
    GalacticObjectLaboratoryCaseId,

  label:
    string,

  morphology:
    SupernovaRemnantMorphologyValue,

  representatives:
    ReadonlyMap<
      SupernovaRemnantMorphologyValue,
      GalacticObjectLocator
    >,
): GalacticObjectLaboratoryCase {

  const locator =
    representatives.get(
      morphology,
    );

  if (
    locator ===
      undefined
  ) {
    throw new RangeError(
      `Missing V1 supernova-remnant laboratory representative for ${morphology}.`,
    );
  }

  return caseOf(
    id,
    GalacticObjectLaboratoryGroup.SUPERNOVA_REMNANTS,
    label,
    'Remanente persistente',
    locator,
    ExplorationResultKind.EXTREME_OBJECT,
    GalacticObjectScientificSubject.SUPERNOVA_REMNANT,
    null,
    null,
    morphology,
    `Remanente de supernova V1 con morfología ${morphology}.`,
  );
}

function hiiRepresentativesV1():
  ReadonlyMap<
    StarFormationActivityValue,
    GalacticObjectLocator
  > {

  if (
    cachedHiiRepresentatives !==
      null
  ) {
    return cachedHiiRepresentatives;
  }

  const found =
    new Map<
      StarFormationActivityValue,
      GalacticObjectLocator
    >();

  for (
    let index =
      0n;
    index <
      2_048n;
    index +=
      1n
  ) {
    const locator =
      new GalacticObjectLocator(
        0n,
        NEBULA_SECTOR_KEY,
        index,
      );

    if (
      !HiiRegionGenerator
        .isHiiRegionLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const region =
      HiiRegionGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      !found.has(
        region
          .starFormationProfile
          .activity,
      )
    ) {
      found.set(
        region
          .starFormationProfile
          .activity,
        locator,
      );
    }

    if (
      found.size ===
      Object.values(
        StarFormationActivity,
      ).length
    ) {
      break;
    }
  }

  if (
    found.size !==
    Object.values(
      StarFormationActivity,
    ).length
  ) {
    throw new RangeError(
      'The canonical V1 laboratory sample did not reach all H II activity levels.',
    );
  }

  cachedHiiRepresentatives =
    found;

  return found;
}

function remnantRepresentativesV1():
  ReadonlyMap<
    SupernovaRemnantMorphologyValue,
    GalacticObjectLocator
  > {

  if (
    cachedRemnantRepresentatives !==
      null
  ) {
    return cachedRemnantRepresentatives;
  }

  const found =
    new Map<
      SupernovaRemnantMorphologyValue,
      GalacticObjectLocator
    >();

  for (
    let index =
      0n;
    index <
      2_048n;
    index +=
      1n
  ) {
    const locator =
      new GalacticObjectLocator(
        0n,
        0n,
        index,
      );

    if (
      !SupernovaRemnantGenerator
        .isSupernovaRemnantLocator(
          GENERATION_KEY,
          locator,
        )
    ) {
      continue;
    }

    const remnant =
      SupernovaRemnantGenerator
        .generate(
          GENERATION_KEY,
          locator,
        );

    if (
      !found.has(
        remnant.morphology,
      )
    ) {
      found.set(
        remnant.morphology,
        locator,
      );
    }

    if (
      found.size ===
      Object.values(
        SupernovaRemnantMorphology,
      ).length
    ) {
      break;
    }
  }

  if (
    found.size !==
    Object.values(
      SupernovaRemnantMorphology,
    ).length
  ) {
    throw new RangeError(
      'The canonical V1 laboratory sample did not reach all supernova-remnant morphologies.',
    );
  }

  cachedRemnantRepresentatives =
    found;

  return found;
}
