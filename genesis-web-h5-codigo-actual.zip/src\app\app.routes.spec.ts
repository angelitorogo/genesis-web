import { TestBed } from '@angular/core/testing';
import {
  provideRouter,
  Router,
} from '@angular/router';
import {
  RouterTestingHarness,
} from '@angular/router/testing';

import { genesisRoutes } from './app.routes';

describe('GENESIS routes', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideRouter(genesisRoutes),
      ],
    });
  });


  it('30.5 navigates to unresolved mysteries without Home wildcard', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/mysteries/unresolved');
    expect(TestBed.inject(Router).url).toBe('/laboratory/mysteries/unresolved');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="mystery-unresolved-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('30.4 navigates directly to classification without Home wildcard', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/mysteries/classification');
    expect(TestBed.inject(Router).url).toBe('/laboratory/mysteries/classification');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="mystery-classification-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('30.3 navigates to scientific actions without Home wildcard fallback', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/mysteries/actions');
    expect(TestBed.inject(Router).url).toBe('/laboratory/mysteries/actions');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="mystery-actions-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('30.2 navigates to evidence without Home wildcard fallback', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/mysteries/evidence');
    expect(TestBed.inject(Router).url).toBe('/laboratory/mysteries/evidence');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="mystery-evidence-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('29.12 navigates to time control without Home wildcard fallback', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/transient-events/time-control');
    expect(TestBed.inject(Router).url).toBe('/laboratory/transient-events/time-control');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="transient-time-control-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('29.11 navigates to historical effects without the Home wildcard', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/transient-events/historical-effects');
    expect(TestBed.inject(Router).url).toBe('/laboratory/transient-events/historical-effects');
    expect(harness.routeNativeElement?.querySelector('[data-testid="transient-historical-effects-laboratory"]')).toBeTruthy();
  }, 30_000);

  it('29.10 navigates to the follow-up laboratory without Home wildcard fallback', async () => {
    const harness = await RouterTestingHarness.create('/laboratory/transient-events/follow-up');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/follow-up');
    expect(harness.routeNativeElement?.querySelector(
      '[data-testid="transient-follow-up-laboratory"]',
    )).toBeTruthy();
  }, 30_000);

  it('should navigate to Home from the root route', async () => {
    const harness =
      await RouterTestingHarness.create('/');

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="home-page"]',
      ),
    ).toBeTruthy();

    expect(
      harness.routeNativeElement?.textContent,
    ).toContain('GENESIS');
  }, 30_000);

  it('should use the root URL for Home', async () => {
    await RouterTestingHarness.create('/');

    const router =
      TestBed.inject(Router);

    expect(router.url).toBe('/');
  });

  it('should navigate to Exploration', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/exploration',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="exploration-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to Galaxy Map', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/galaxy-map',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="galaxy-map-page"]',
      ),
    ).toBeTruthy();
  });

  it('should expose the point-24.1 stellar-system scene route', () => {
    const route =
      genesisRoutes.find(
        (candidate) =>
          candidate.path ===
          'system/:galaxyIndex/:sectorKey/:galacticObjectIndex',
      );

    expect(
      route,
    ).toBeDefined();

    expect(
      route?.title,
    ).toBe(
      'Sistema estelar | GENESIS',
    );
  });

  it('should navigate to Discovered Galaxies', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/galaxies',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="discovered-galaxies-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to the point-11.3 Galaxy general detail route', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/galaxies/0',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="galaxy-detail-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);


  it('should keep the point-26.1c generic knowledge catalogue route reachable before the Galaxy detail wildcard-shaped route', () => {
    const knowledgeCatalog = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex/knowledge/:category');
    const galaxyDetail = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex');

    expect(knowledgeCatalog).toBeGreaterThanOrEqual(0);
    expect(knowledgeCatalog).toBeLessThan(galaxyDetail);
    expect(genesisRoutes[knowledgeCatalog]?.title).toBe(
      'Explorador de conocimiento galáctico | GENESIS',
    );
  });

  it('should navigate to the point-26.1c generic knowledge catalogue instead of falling back to Home', async () => {
    const harness = await RouterTestingHarness.create(
      '/galaxies/0/knowledge/systems',
    );
    const router = TestBed.inject(Router);

    expect(router.url).toBe('/galaxies/0/knowledge/systems');
    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="galaxy-knowledge-catalog-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should expose the point-26.1c water-world index route before the generic Galaxy detail route', () => {
    const waterIndex = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex/water-worlds');
    const galaxyDetail = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex');

    expect(waterIndex).toBeGreaterThanOrEqual(0);
    expect(waterIndex).toBeLessThan(galaxyDetail);
  });

  it('should expose the point-26.1c lunar water index route before the generic Galaxy detail route', () => {
    const waterMoonIndex = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex/water-moons');
    const galaxyDetail = genesisRoutes.findIndex(route =>
      route.path === 'galaxies/:galaxyIndex');

    expect(waterMoonIndex).toBeGreaterThanOrEqual(0);
    expect(waterMoonIndex).toBeLessThan(galaxyDetail);
  });

  it('should expose the point-11.3 Galaxy detail route before the catalogue route', () => {
    const detailIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'galaxies/:galaxyIndex',
      );

    const catalogueIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'galaxies',
      );

    expect(
      detailIndex,
    ).toBeGreaterThanOrEqual(
      0,
    );

    expect(
      detailIndex,
    ).toBeLessThan(
      catalogueIndex,
    );
  });

  it('should navigate to Observatory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/observatory',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="observatory-page"]',
      ),
    ).toBeTruthy();
  });

  it('should navigate to Genesis Archive', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/archive',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="genesis-archive-page"]',
      ),
    ).toBeTruthy();
  });


  it('should expose the point-10.6 SystemLocator Archive detail route before the base Archive route', () => {
    const detailIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'archive/system/:galaxyIndex/:sectorKey/:galacticObjectIndex',
      );

    const archiveIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'archive',
      );

    expect(
      detailIndex,
    ).toBeGreaterThanOrEqual(
      0,
    );

    expect(
      detailIndex,
    ).toBeLessThan(
      archiveIndex,
    );

    expect(
      genesisRoutes[
        detailIndex
      ]?.data?.[
        'archiveDiscoveryLocatorKind'
      ],
    ).toBe(
      'system',
    );
  });

  it('should expose the point-10.6 GalacticObjectLocator Archive detail route before the base Archive route', () => {
    const detailIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'archive/galactic-object/:galaxyIndex/:sectorKey/:galacticObjectIndex',
      );

    const archiveIndex =
      genesisRoutes.findIndex(
        (route) =>
          route.path ===
          'archive',
      );

    expect(
      detailIndex,
    ).toBeGreaterThanOrEqual(
      0,
    );

    expect(
      detailIndex,
    ).toBeLessThan(
      archiveIndex,
    );

    expect(
      genesisRoutes[
        detailIndex
      ]?.data?.[
        'archiveDiscoveryLocatorKind'
      ],
    ).toBe(
      'galactic-object',
    );
  });


  it('should navigate to the permanent GENESIS Visual Laboratory index', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="laboratory-page"]',
      ),
    ).toBeTruthy();
  });

  it('should navigate to the real five-morphology galaxy laboratory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/galaxies',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="galaxy-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to the GalacticObject knowledge-progression laboratory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/galactic-objects',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="galactic-object-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to the canonical spectroscopy laboratory route', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/spectroscopy',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="spectroscopy-validation-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to the phase-16 stellar-system A-H knowledge-progression laboratory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/stellar-systems',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="stellar-system-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);


  it('should keep both 29.1 supernova laboratories reachable after adding the post-supernova audit route', () => {
    const supernova = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/supernovae');
    const postSupernova = genesisRoutes.find(route =>
      route.path === 'laboratory/stellar-systems/post-supernova-audit');

    expect(supernova?.title).toBe('Supernovas | Laboratorios GENESIS');
    expect(postSupernova?.title).toBe('Auditoría post-supernova | Laboratorios GENESIS');
  });

  it('should navigate to the 29.1A supernova laboratory instead of falling back to Home', async () => {
    const harness = await RouterTestingHarness.create(
      '/laboratory/transient-events/supernovae',
    );
    const router = TestBed.inject(Router);

    expect(router.url).toBe('/laboratory/transient-events/supernovae');
    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="supernova-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should expose and navigate to the complete 29.2 nova laboratory', async () => {
    const nova = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/novae');
    expect(nova?.title).toBe('Novas | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create(
      '/laboratory/transient-events/novae',
    );
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/novae');
    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="nova-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to the deterministic 29.1E-g.1 post-supernova audit laboratory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/stellar-systems/post-supernova-audit',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="post-supernova-audit-page"]',
      ),
    ).toBeTruthy();
  }, 120_000);

  it('should navigate to the phase-17 protoplanetary-formation laboratory', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/laboratory/planetary-formation',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="planetary-formation-laboratory-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should expose and navigate to the complete 29.3 kilonova laboratory', async () => {
    const kilonova = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/kilonovae');
    expect(kilonova?.title).toBe('Kilonovas | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/kilonovae');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/kilonovae');
    expect(harness.routeNativeElement?.querySelector('[data-testid="kilonova-laboratory-page"]')).toBeTruthy();
  });

  it('should expose and navigate to the complete 29.4 compact-merger laboratory', async () => {
    const merger = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/compact-mergers');
    expect(merger?.title).toBe('Fusiones compactas | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/compact-mergers');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/compact-mergers');
    expect(harness.routeNativeElement?.querySelector('[data-testid="compact-merger-laboratory-page"]')).toBeTruthy();
  });


  it('should expose and navigate to the complete 29.5 gravitational-wave laboratory', async () => {
    const waves = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/gravitational-waves');
    expect(waves?.title).toBe('Ondas gravitacionales | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/gravitational-waves');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/gravitational-waves');
    expect(harness.routeNativeElement?.querySelector('[data-testid="gravitational-wave-laboratory-page"]')).toBeTruthy();
  });

  it('should expose and navigate to the complete 29.6 tidal-disruption laboratory', async () => {
    const tidal = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/tidal-disruptions');
    expect(tidal?.title).toBe('Disrupciones de marea | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/tidal-disruptions');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/tidal-disruptions');
    expect(harness.routeNativeElement?.querySelector('[data-testid="tidal-disruption-laboratory-page"]')).toBeTruthy();
  });

  it('should expose and navigate to the complete 29.7 gamma-ray-burst laboratory', async () => {
    const grb = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/gamma-ray-bursts');
    expect(grb?.title).toBe('Estallidos de rayos gamma | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/gamma-ray-bursts');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/gamma-ray-bursts');
    expect(harness.routeNativeElement?.querySelector('[data-testid="gamma-ray-burst-laboratory-page"]')).toBeTruthy();
  });

  it('should expose and navigate to the complete 29.8 fast-radio-burst laboratory', async () => {
    const frb = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/fast-radio-bursts');
    expect(frb?.title).toBe('Fast Radio Bursts | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/fast-radio-bursts');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/fast-radio-bursts');
    expect(harness.routeNativeElement?.querySelector('[data-testid="fast-radio-burst-laboratory-page"]')).toBeTruthy();
  });

  it('should expose and navigate to the complete 29.9 great-stellar-flare laboratory', async () => {
    const flare = genesisRoutes.find(route =>
      route.path === 'laboratory/transient-events/great-stellar-flares');
    expect(flare?.title).toBe('Grandes llamaradas estelares | Laboratorios GENESIS');

    const harness = await RouterTestingHarness.create('/laboratory/transient-events/great-stellar-flares');
    const router = TestBed.inject(Router);
    expect(router.url).toBe('/laboratory/transient-events/great-stellar-flares');
    expect(harness.routeNativeElement?.querySelector('[data-testid="great-stellar-flare-laboratory-page"]')).toBeTruthy();
  });

  it('should keep the legacy spectroscopy-validation URL as a compatible redirect', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/spectroscopy-validation',
      );

    const router =
      TestBed.inject(Router);

    expect(
      router.url,
    ).toBe(
      '/laboratory/spectroscopy',
    );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="spectroscopy-validation-page"]',
      ),
    ).toBeTruthy();
  }, 30_000);

  it('should navigate to Códigos', async () => {
    const harness = await RouterTestingHarness.create('/codes');
    expect(harness.routeNativeElement?.querySelector('[data-testid="codes-page"]')).toBeTruthy();
    expect(harness.routeNativeElement?.querySelector('[data-testid="codes-input"]')).toBeTruthy();
    expect(harness.routeNativeElement?.querySelector('[data-testid="codes-accept"]')).toBeTruthy();
  });

  it('should navigate to Statistics', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/statistics',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="statistics-page"]',
      ),
    ).toBeTruthy();
  });

  it('should navigate to Settings', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/settings',
      );

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="settings-page"]',
      ),
    ).toBeTruthy();
  });

  it('should redirect unknown routes to Home', async () => {
    const harness =
      await RouterTestingHarness.create(
        '/ruta-inexistente',
      );

    const router =
      TestBed.inject(Router);

    expect(router.url).toBe('/');

    expect(
      harness.routeNativeElement?.querySelector(
        '[data-testid="home-page"]',
      ),
    ).toBeTruthy();
  });
});
