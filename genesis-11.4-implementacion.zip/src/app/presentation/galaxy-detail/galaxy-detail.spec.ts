import {
  TestBed,
} from '@angular/core/testing';

import {
  ActivatedRoute,
  provideRouter,
} from '@angular/router';

import {
  DiscoveryState,
  type DiscoveryStateValue,
} from '../../domain/discovery/discovery-state';

import {
  KnownDiscovery,
} from '../../domain/discovery/known-discovery';

import {
  BodyLocator,
  CivilizationLocator,
  GalacticObjectLocator,
  GalaxyLocator,
  SectorLocator,
  SystemLocator,
} from '../../domain/generation/procedural-locator';

import {
  GeneratorVersion,
} from '../../domain/generation/generator-version';

import {
  UniverseGenerationKey,
} from '../../domain/generation/universe-generation-key';

import {
  GalaxyType,
} from '../../domain/universe/galaxy-type';

import {
  UniverseSeed,
} from '../../domain/universe/universe-seed';

import {
  GENESIS_LOCAL_REPOSITORIES,
  type GenesisLocalRepositories,
} from '../runtime/genesis-local-repositories';

import {
  DEFAULT_UNIVERSE_SEED,
} from '../universe/universe-seed.facade';

import {
  GalaxyDetailFacade,
} from './galaxy-detail.facade';

import {
  GalaxyDetailPage,
} from './galaxy-detail';

describe(
  'GalaxyDetailPage',
  () => {
    const generationKey =
      new UniverseGenerationKey(
        UniverseSeed.parse(
          DEFAULT_UNIVERSE_SEED,
        ),
        GeneratorVersion.V1,
      );

    const defaultStates =
      new Map<
        bigint,
        DiscoveryStateValue
      >([
        [
          0n,
          DiscoveryState
            .DISCOVERED,
        ],
        [
          1n,
          DiscoveryState
            .DETECTED,
        ],
      ]);

    function galaxyDiscoveriesFromStates(
      states:
        ReadonlyMap<
          bigint,
          DiscoveryStateValue
        >,
    ): readonly KnownDiscovery[] {

      return [
        ...states,
      ]
        .filter(
          (
            [
              ,
              state,
            ],
          ) =>
            DiscoveryState
              .isKnown(
                state,
              ),
        )
        .map(
          (
            [
              galaxyIndex,
              state,
            ],
          ) =>
            new KnownDiscovery(
              generationKey,
              new GalaxyLocator(
                galaxyIndex,
              ),
              state,
            ),
        );
    }

    function repositories(
      states:
        ReadonlyMap<
          bigint,
          DiscoveryStateValue
        > =
          defaultStates,

      activeGalaxyIndex =
        0n,

      universes:
        readonly UniverseGenerationKey[] =
          [
            generationKey,
          ],

      knownDiscoveries:
        readonly KnownDiscovery[] =
          galaxyDiscoveriesFromStates(
            states,
          ),
    ): GenesisLocalRepositories {

      return {
        universeRepository: {
          async createIfAbsent() {
            return false;
          },

          async exists() {
            return true;
          },

          async getAll() {
            return universes;
          },

          async delete() {
            return false;
          },
        },

        navigationRepository: {
          async getNavigation() {
            return {
              activeGalaxyIndex,

              recentGalaxyIndices:
                [],
            };
          },

          async setNavigation() {
            throw new Error(
              '11.4 must not change the active galaxy.',
            );
          },
        },

        pointsRepository: {
          async getGlobalDiscoveryPoints() {
            throw new Error(
              '11.4 must not read global PD.',
            );
          },

          async setGlobalDiscoveryPoints() {
            throw new Error(
              '11.4 must not write global PD.',
            );
          },

          async getGalaxyDiscoveryPoints() {
            throw new Error(
              '11.4 structural progress must not be conflated with per-galaxy PD.',
            );
          },

          async setGalaxyDiscoveryPoints() {
            throw new Error(
              '11.4 must not write per-galaxy PD.',
            );
          },
        },

        discoveryRepository: {
          async getState(
            _generationKey,
            locator,
          ) {
            if (
              !(
                locator instanceof
                GalaxyLocator
              )
            ) {
              throw new Error(
                '11.4 must query exactly one GalaxyLocator before loading statistics.',
              );
            }

            return (
              states.get(
                locator
                  .galaxyIndex,
              ) ??
              DiscoveryState
                .UNKNOWN
            );
          },

          async setState() {
            throw new Error(
              '11.4 must not mutate DiscoveryState.',
            );
          },

          async getKnownDiscoveries() {
            return knownDiscoveries;
          },

          async getKnownDiscoveriesInSector() {
            throw new Error(
              '11.4 must not materialize sector content.',
            );
          },
        },
      };
    }

    function configure(
      galaxyIndex:
        string,

      repositoryBundle:
        GenesisLocalRepositories =
          repositories(),
    ): void {

      TestBed.configureTestingModule({
        imports: [
          GalaxyDetailPage,
        ],

        providers: [
          provideRouter(
            [],
          ),

          {
            provide:
              ActivatedRoute,

            useValue: {
              snapshot: {
                paramMap: {
                  get(
                    key:
                      string,
                  ) {
                    return key ===
                      'galaxyIndex'
                      ? galaxyIndex
                      : null;
                  },
                },
              },
            },
          },

          {
            provide:
              GENESIS_LOCAL_REPOSITORIES,

            useValue:
              repositoryBundle,
          },
        ],
      });
    }

    it(
      'should load canonical Caeloria with its own bootstrap statistics without reading PD or changing focus',
      async () => {
        configure(
          '0',
        );

        const facade =
          TestBed.inject(
            GalaxyDetailFacade,
          );

        await facade
          .load(
            '0',
          );

        const model =
          facade.model();

        expect(
          model,
        ).not.toBeNull();

        expect(
          model
            ?.profile
            .knownName,
        ).toBe(
          'Caeloria',
        );

        expect(
          model
            ?.profile
            .galaxyType,
        ).toBe(
          GalaxyType
            .ELLIPTICAL,
        );

        expect(
          model
            ?.statistics
            .progressUnits,
        ).toBe(
          2n,
        );

        expect(
          model
            ?.statistics
            .knownRecords,
        ).toBe(
          1n,
        );

        expect(
          model
            ?.statistics
            .internalKnownRecords,
        ).toBe(
          0n,
        );

        expect(
          model
            ?.isCurrentFocus,
        ).toBe(true);

        expect(
          model
            ?.isOriginGalaxy,
        ).toBe(true);
      },
      15_000,
    );

    it(
      'should render the point-11.4 profile, local progress and known-record statistics',
      async () => {
        configure(
          '0',
        );

        await TestBed
          .compileComponents();

        const fixture =
          TestBed.createComponent(
            GalaxyDetailPage,
          );

        fixture.detectChanges();

        await fixture
          .componentInstance
          .facade
          .load(
            '0',
          );

        fixture.detectChanges();

        const element =
          fixture.nativeElement as
            HTMLElement;

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-page"]',
          ),
        ).toBeTruthy();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-name"]',
          )?.textContent,
        ).toContain(
          'Caeloria',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-index"]',
          )?.textContent,
        ).toContain(
          'Galaxia 0',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-state"]',
          )?.textContent,
        ).toContain(
          'Descubierta',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-exact-type"]',
          )?.textContent,
        ).toContain(
          'Elíptica',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-morphology"]',
          )?.textContent,
        ).toContain(
          'Esferoidal',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-scale"]',
          )?.textContent,
        ).toContain(
          'Grande',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-population"]',
          )?.textContent,
        ).toContain(
          'Alta',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-nuclear"]',
          )?.textContent,
        ).toContain(
          'Sin actividad nuclear clara',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-progress"]',
          ),
        ).toBeTruthy();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-progress-units"]',
          )?.textContent,
        ).toContain(
          '2',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-known-records"]',
          )?.textContent,
        ).toContain(
          '1',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-known-sectors"]',
          )?.textContent,
        ).toContain(
          '0',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-state-discovered"]',
          )?.textContent,
        ).toContain(
          '1',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-progress-no-percentage"]',
          )?.textContent,
        ).toContain(
          'No son PD ni un porcentaje',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-focus-badge"]',
          ),
        ).toBeTruthy();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-origin-badge"]',
          ),
        ).toBeTruthy();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-map-link"]',
          ),
        ).toBeTruthy();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-boundary"]',
          )?.textContent,
        ).toContain(
          '11.4',
        );
      },
      15_000,
    );

    it(
      'should derive statistics from every known locator in the requested galaxy only',
      async () => {
        const knownDiscoveries =
          [
            new KnownDiscovery(
              generationKey,
              new GalaxyLocator(
                0n,
              ),
              DiscoveryState
                .DISCOVERED,
            ),

            new KnownDiscovery(
              generationKey,
              new SectorLocator(
                0n,
                10n,
              ),
              DiscoveryState
                .DETECTED,
            ),

            new KnownDiscovery(
              generationKey,
              new GalacticObjectLocator(
                0n,
                10n,
                1n,
              ),
              DiscoveryState
                .VISITED,
            ),

            new KnownDiscovery(
              generationKey,
              new SystemLocator(
                0n,
                10n,
                2n,
              ),
              DiscoveryState
                .CONFIRMED,
            ),

            new KnownDiscovery(
              generationKey,
              new BodyLocator(
                0n,
                10n,
                2n,
                4n,
              ),
              DiscoveryState
                .CATALOGUED,
            ),

            new KnownDiscovery(
              generationKey,
              new CivilizationLocator(
                0n,
                10n,
                2n,
                4n,
                1n,
              ),
              DiscoveryState
                .DISCOVERED,
            ),

            new KnownDiscovery(
              generationKey,
              new GalaxyLocator(
                1n,
              ),
              DiscoveryState
                .CONFIRMED,
            ),

            new KnownDiscovery(
              generationKey,
              new SystemLocator(
                1n,
                20n,
                3n,
              ),
              DiscoveryState
                .CONFIRMED,
            ),
          ];

        configure(
          '0',
          repositories(
            defaultStates,
            0n,
            [
              generationKey,
            ],
            knownDiscoveries,
          ),
        );

        const facade =
          TestBed.inject(
            GalaxyDetailFacade,
          );

        await facade
          .load(
            '0',
          );

        const statistics =
          facade
            .model()
            ?.statistics;

        expect(
          statistics
            ?.progressUnits,
        ).toBe(
          17n,
        );

        expect(
          statistics
            ?.knownRecords,
        ).toBe(
          6n,
        );

        expect(
          statistics
            ?.targetCounts,
        ).toEqual({
          sectors:
            1n,

          galacticObjects:
            1n,

          systems:
            1n,

          bodies:
            1n,

          civilizations:
            1n,
        });

        expect(
          statistics
            ?.stateCounts,
        ).toEqual({
          detected:
            1n,

          discovered:
            2n,

          visited:
            1n,

          catalogued:
            1n,

          confirmed:
            1n,
        });
      },
      15_000,
    );

    it(
      'should render a DETECTED external galaxy without leaking proper name or exact GalaxyType',
      async () => {
        configure(
          '1',
        );

        await TestBed
          .compileComponents();

        const fixture =
          TestBed.createComponent(
            GalaxyDetailPage,
          );

        fixture.detectChanges();

        await fixture
          .componentInstance
          .facade
          .load(
            '1',
          );

        fixture.detectChanges();

        const element =
          fixture.nativeElement as
            HTMLElement;

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-name"]',
          ),
        ).toBeNull();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-index"]',
          )?.textContent,
        ).toContain(
          'Galaxia 1',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-name-restricted"]',
          )?.textContent,
        ).toContain(
          'Nombre propio aún no resuelto',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-exact-type"]',
          ),
        ).toBeNull();

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-exact-type-restricted"]',
          )?.textContent,
        ).toContain(
          'Aún no resuelto',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-state"]',
          )?.textContent,
        ).toContain(
          'Detectada',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-morphology"]',
          )?.textContent,
        ).toContain(
          'Disco galáctico',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-progress-units"]',
          )?.textContent,
        ).toContain(
          '1',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-known-records"]',
          )?.textContent,
        ).toContain(
          '1',
        );

        expect(
          element.querySelector(
            '[data-testid="galaxy-detail-map-link"]',
          ),
        ).toBeNull();
      },
      15_000,
    );

    it(
      'should expose not-found for an UNKNOWN URL target without enumerating hidden content',
      async () => {
        const baseRepositories =
          repositories();

        const repositoryBundle:
          GenesisLocalRepositories =
          {
            ...baseRepositories,

            discoveryRepository: {
              ...baseRepositories
                .discoveryRepository,

              async getKnownDiscoveries() {
                throw new Error(
                  'UNKNOWN targets must be rejected before statistics are enumerated.',
                );
              },
            },
          };

        configure(
          '99',
          repositoryBundle,
        );

        const facade =
          TestBed.inject(
            GalaxyDetailFacade,
          );

        await facade
          .load(
            '99',
          );

        expect(
          facade.state().kind,
        ).toBe(
          'not-found',
        );

        expect(
          facade.model(),
        ).toBeNull();
      },
    );

    it(
      'should expose Empty when no persisted universe exists',
      async () => {
        configure(
          '0',
          repositories(
            new Map<
              bigint,
              DiscoveryStateValue
            >(),
            0n,
            [],
            [],
          ),
        );

        const facade =
          TestBed.inject(
            GalaxyDetailFacade,
          );

        await facade
          .load(
            '0',
          );

        expect(
          facade.state().kind,
        ).toBe(
          'empty',
        );
      },
    );

    it(
      'should reject malformed or out-of-range galaxyIndex route values',
      async () => {
        configure(
          '0',
        );

        const facade =
          TestBed.inject(
            GalaxyDetailFacade,
          );

        await facade
          .load(
            '-1',
          );

        expect(
          facade.state().kind,
        ).toBe(
          'error',
        );

        await facade
          .load(
            (
              1n <<
              63n
            ).toString(
              10,
            ),
          );

        expect(
          facade.state().kind,
        ).toBe(
          'error',
        );
      },
    );
  },
);
