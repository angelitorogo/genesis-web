/**
 * Scientific subject families with a complete Ground Truth model and a
 * dedicated post-DISCOVERED action route. The first five entries are the
 * frozen point-12.7 V1 contract; later entries are additive V2 profiles.
 *
 * This is deliberately separate from the frozen point-8.9 generic
 * ObservationClassification catalog. It is an action-routing contract, not a
 * replacement for that generic classification model.
 */
export enum GalacticObjectScientificSubject {
  NEBULA =
    'NEBULA',

  HII_REGION =
    'HII_REGION',

  OPEN_CLUSTER =
    'OPEN_CLUSTER',

  GLOBULAR_CLUSTER =
    'GLOBULAR_CLUSTER',

  SUPERNOVA_REMNANT =
    'SUPERNOVA_REMNANT',

  /** 27.10 V2: rare real 27.2 specialization, not the reserved complement. */
  INTERMEDIATE_MASS_BLACK_HOLE =
    'INTERMEDIATE_MASS_BLACK_HOLE',

  /** V2 reserved centre with existing AGN or QUASAR nuclear Ground Truth. */
  ACTIVE_GALACTIC_NUCLEUS =
    'ACTIVE_GALACTIC_NUCLEUS',

  /**
   * 28.2G.3 generic post-DISCOVERED route for distributed V2 extremes whose
   * exact ExtremeType remains hidden until CATALOGUED. This is an action
   * routing subject, not a replacement for the canonical ExtremeType.
   */
  DISTRIBUTED_EXTREME_OBJECT =
    'DISTRIBUTED_EXTREME_OBJECT',
}

/**
 * Coarse point-9.4 families used only by the first scientific survey.
 *
 * Keeping these separate from GalacticObjectScientificSubject is the key
 * anti-leak boundary: while the target is merely DETECTED, the action system
 * can route a survey from the already-known coarse family without resolving
 * hidden point-12.x physical Ground Truth.
 */
export enum GalacticObjectScientificSurveyFamily {
  NEBULA =
    'NEBULA',

  STAR_CLUSTER =
    'STAR_CLUSTER',

  EXTREME_OBJECT =
    'EXTREME_OBJECT',
}
