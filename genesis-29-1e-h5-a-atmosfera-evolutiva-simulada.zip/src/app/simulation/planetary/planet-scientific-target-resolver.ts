import {
  BodyLocator,
  SystemLocator,
} from '../../domain/generation/procedural-locator';

import {
  type UniverseGenerationKey,
} from '../../domain/generation/universe-generation-key';

import {
  type PlanetarySystemOrbitTopology,
} from '../../domain/planetary/planetary-system-orbit-topology';

import {
  GalaxySectorKeyCodec,
} from '../../domain/sector/galaxy-sector-key-codec';

import {
  GalaxySectorGridGenerator,
} from '../sector/galaxy-sector-grid-generator';

import {
  GalaxySectorStellarDensityGenerator,
} from '../sector/galaxy-sector-stellar-density-generator';

import {
  GalaxySectorStellarPopulationPropertiesGenerator,
} from '../sector/galaxy-sector-stellar-population-properties-generator';

import {
  StellarPopulationProfileGenerator,
} from '../stellar/stellar-population-profile-generator';

import {
  StellarSystemGenerator,
} from '../stellar/stellar-system-generator';

import {
  GalaxyGenerator,
} from '../universe/galaxy-generator';

import {
  AtmosphereGenerator,
} from './atmosphere-generator';

import {
  MoonGenerator,
} from './moon-generator';

import {
  PlanetGenerator,
} from './planet-generator';

import {
  PlanetaryFormationMaturationGenerator,
} from './planetary-formation-maturation-generator';

import {
  PlanetarySystemGenerator,
} from './planetary-system-generator';

import {
  ProtoplanetaryFormationSnapshotGenerator,
} from './protoplanetary-formation-snapshot-generator';

import {
  type PostRemnantConditionalEnvironmentReassessment,
} from './post-remnant-conditional-environment-reassessment';
import {type PostAgbAtmosphereScenario} from './white-dwarf-post-agb-atmosphere-projection';
import {type WhiteDwarfPostAgbAtmosphereHistory} from './white-dwarf-post-agb-atmosphere-history';
import {type PostAgbPlanetarySurvivalAssessment} from './white-dwarf-post-agb-planetary-survival';
import {type WhiteDwarfPostAgbEnvironmentalResolution} from './white-dwarf-post-agb-environment-resolution';
import type { WhiteDwarfEvolvedEnvironment } from './white-dwarf-post-agb-evolved-environment';

export interface PlanetScientificIdentitySource {
  readonly locator:
    BodyLocator;

  readonly planetOrdinal:
    number;

  readonly designation:
    string;

  readonly hostSystemDesignation:
    string;

  readonly orbitTopology:
    PlanetarySystemOrbitTopology;

  readonly hostPlanetCount:
    number;
}

export interface PlanetScientificGasSource {
  readonly gas:
    string;

  readonly moleFraction01:
    number;
}

export interface PlanetScientificRelevantMoonSource {
  readonly designation:
    string;

  readonly moonOrdinal:
    number;

  readonly moonIndex:
    number;

  readonly massEarth:
    number;

  readonly radiusEarth:
    number;

  readonly meanDensityGramsPerCubicCentimeter:
    number;

  readonly surfaceGravityEarth:
    number;

  readonly semiMajorAxisPlanetRadii:
    number;

  readonly semiMajorAxisKilometers:
    number;

  readonly eccentricity:
    number;

  readonly inclinationDegrees:
    number;

  readonly orbitalPeriodDays:
    number;

  readonly rocheLimitPlanetRadii:
    number;

  readonly hillSphereRadiusPlanetRadii:
    number;

  readonly synchronousOrbitPlanetRadii:
    number;

  readonly tidalForcingIndex01:
    number;

  readonly tidalHeatingIndex01:
    number;

  readonly tidalRegime:
    string;

  readonly tidalLockingIndex01:
    number;

  readonly tidalLockingRegime:
    string;

  readonly rotationPeriodHours:
    number;

  readonly migrationRegime:
    string;

  readonly isTidallyLocked:
    boolean;

  readonly referenceMeanInsolationEarth:
    number;

  readonly inferredIceRichnessIndex01:
    number;

  readonly inferredBondAlbedo01:
    number;

  readonly equilibriumTemperatureKelvin:
    number;

  readonly estimatedSurfaceTemperatureKelvin:
    number;

  readonly atmosphereRetentionIndex01:
    number;

  readonly atmosphereRegime:
    string;

  readonly waterInventoryIndex01:
    number;

  readonly subsurfaceOceanPotentialIndex01:
    number;

  readonly surfaceLiquidWaterPotentialIndex01:
    number;

  readonly waterRegime:
    string;

  readonly internalHeatRetentionIndex01:
    number;

  readonly geologicalActivityIndex01:
    number;

  readonly geologyRegime:
    string;

  readonly hasAtmosphere:
    boolean;

  readonly hasWater:
    boolean;

  readonly hasSubsurfaceOcean:
    boolean;

  readonly hasSurfaceLiquidWater:
    boolean;

  readonly isGeologicallyActive:
    boolean;

  readonly surfaceTemperatureSupportIndex01:
    number;

  readonly surfaceAtmosphereSupportIndex01:
    number;

  readonly surfaceGravitySupportIndex01:
    number;

  readonly tidalModerationIndex01:
    number;

  readonly subsurfaceEnergySupportIndex01:
    number;

  readonly surfaceHabitabilityIndex01:
    number;

  readonly subsurfaceHabitabilityIndex01:
    number;

  readonly overallHabitabilityIndex01:
    number;

  readonly surfaceHabitabilityCandidate:
    boolean;

  readonly subsurfaceHabitabilityCandidate:
    boolean;

  readonly habitabilityRegime:
    string;

  readonly isPotentiallyHabitable:
    boolean;

  readonly giantHostSpecialization:
    boolean;

  readonly giantMoonOrbitalFamily:
    string;

  readonly giantMoonCompositionRegime:
    string;

  readonly isLargeGiantMoon:
    boolean;

  readonly isTidallyActiveGiantMoon:
    boolean;

  readonly isOceanBearingGiantMoonCandidate:
    boolean;
}

export interface PlanetScientificDetailSource {
  readonly general:
    Readonly<{
      planetType: string;
      massEarth: number;
      radiusEarth: number;
      densityGramsPerCubicCentimeter: number;
      surfaceGravityEarth: number;
      surfaceGravityMetersPerSecondSquared: number;
      rotationPeriodHours: number;
      dayLengthHours: number | null;
      axialTiltDegrees: number;
      isRetrogradeRotation: boolean;
      isTidallySynchronized: boolean;
      referenceBondAlbedo01: number;
      isTypePhysicallyCoherent: boolean;
      metallicCoreMassFraction01: number;
      silicateInteriorMassFraction01: number;
      condensedIceMassFraction01: number;
      volatileRichInteriorMassFraction01: number;
      gaseousEnvelopeMassFraction01: number;
    }>;

  readonly orbit:
    Readonly<{
      semiMajorAxisAu: number;
      eccentricity: number;
      inclinationDegrees: number;
      periastronAu: number;
      apoastronAu: number;
      periodDays: number;
      periodYears: number;
      radiativeHabitableZoneRelation: string;
      dynamicallyAvailableHabitableZoneRelation: string | null;
      referenceMeanInsolationEarth: number;
      tidalHeatingProxy: number;
    }>;

  readonly surface:
    Readonly<{
      surfaceBaseRegime: string;
      hasDefinedSolidSurfaceBase: boolean;
      baseSolidSurfaceRoughness01: number | null;
      waterInventoryIndex01: number;
      waterPhaseRegime: string;
      surfaceWaterRegime: string;
      waterIceFraction01: number | null;
      waterLiquidFraction01: number | null;
      waterVaporFraction01: number | null;
      surfaceIceCoverageFraction01: number | null;
      surfaceLiquidWaterCoverageFraction01: number | null;
      hasPersistentSurfaceLiquidWater: boolean;
      surfaceRadiationRegime: string;
      surfaceRadiationProtectionRegime: string;
      surfaceRadiationExposureIndex01: number | null;
      surfaceRadiationProtectionIndex01: number | null;
      hasEffectiveSurfaceRadiationProtection: boolean;
    }>;

  readonly atmosphere:
    Readonly<{
      pressureRegime: string;
      retainedPressureRegime: string;
      retainedSurfacePressurePascal: number | null;
      retentionRegime: string;
      atmosphericInventoryRetentionFraction01: number;
      retainedReferenceDensityKilogramsPerCubicMeter: number;
      /** 29.1E-e.2 optional density recomputed from final P/T/composition after cryogenic closure. */
      currentDensityKilogramsPerCubicMeter?: number | null;
      retainedMeanMolarMassGramsPerMole: number | null;
      greenhouseRegime: string;
      longwaveTrappingFraction01: number;
      isVacuum: boolean;
      isDeepEnvelope: boolean;
      retainedGasComposition: readonly PlanetScientificGasSource[];
    }>;

  readonly climate:
    Readonly<{
      equilibriumTemperatureKelvin: number;
      meanSurfaceTemperatureKelvin: number | null;
      greenhouseSurfaceWarmingKelvin: number | null;
      climateStabilityRegime: string;
      climateStabilityIndex01: number | null;
      seasonalTemperatureAmplitudeKelvin: number | null;
      diurnalTemperatureRangeKelvin: number | null;
      minimumSurfaceTemperatureKelvin: number | null;
      maximumSurfaceTemperatureKelvin: number | null;
      heatRedistributionEfficiency01: number;
    }>;

  readonly geology:
    Readonly<{
      geologyRegime: string;
      volcanismRegime: string;
      tectonicRegime: string;
      internalHeatRetentionIndex01: number | null;
      tidalHeatingIndex01: number | null;
      geologicalActivityIndex01: number | null;
      volcanismIndex01: number | null;
      tectonicMobilityIndex01: number | null;
      volatileOutgassingPotential01: number | null;
      surfaceRenewalPotential01: number | null;
      isGeologicallyActive: boolean;
      magneticFieldRegime: string;
      magnetosphereRegime: string;
      dynamoPotentialIndex01: number;
      intrinsicMagneticFieldIndex01: number;
      magnetosphericProtectionIndex01: number;
      hasSustainedDynamo: boolean;
    }>;

  readonly moons:
    Readonly<{
      moonCount: number;
      relevantMoonCount: number;
      unmaterializedMinorMoonCount: number;
      potentiallyHabitableMoonCount: number;
      surfaceHabitabilityCandidateCount: number;
      subsurfaceHabitabilityCandidateCount: number;
      relevantMoons: readonly PlanetScientificRelevantMoonSource[];
    }>;
}

export interface PlanetScientificHostEvolutionContext {
  readonly hostLabel: string;
  readonly evolutionStateNames: readonly string[];
  readonly containsCompactRemnant: boolean;
  readonly requiresPostStellarEvolutionReassessment: boolean;
  readonly currentHostMassSolar: number | null;
  readonly currentHostLuminositySolar: number | null;
  readonly currentOrbitalPeriodDays: number | null;
  readonly currentOrbitalPeriodYears: number | null;
  readonly currentMeanInsolationEarth: number | null;
  readonly radiativeRegime:
    'CURRENT_STELLAR_SOURCE' |
    'QUIESCENT_BLACK_HOLE' |
    'COMPACT_LUMINOSITY_UNMODELED' |
    'WHITE_DWARF_COOLING_ESTIMATE';

  /** 29.1E-H1: estimated WD cooling age; AB hosts have no single WD age. */
  readonly whiteDwarfCoolingAgeBillionYears?: number | null;
  /** Solar-spectrum HZ reference only: not WD spectral or dynamical habitability. */
  readonly currentRadiativeReferenceZoneInnerAu?: number | null;
  readonly currentRadiativeReferenceZoneOuterAu?: number | null;

  /** H3: hypothetical adiabatic WD orbit, NOT a resolved current orbit or
   * guarantee of planetary survival/stability. Formation/canonical unchanged. */
  readonly whiteDwarfPostAgbOrbitalHypothesisApplied?: boolean;
  readonly whiteDwarfPostAgbSemiMajorAxisAu?: number | null;
  readonly whiteDwarfPostAgbPeriodYears?: number | null;
  readonly whiteDwarfPostAgbHostInsolationEarth?: number | null;
  readonly whiteDwarfPostAgbMassExpansionFactor?: number | null;

  /** H2: no atmosphere is inferred; these are conditional bolometric/airless
   * equilibrium bounds using the original (possibly changed) Bond albedo. */
  readonly whiteDwarfThermalEnvelopeApplied?: boolean;
  readonly whiteDwarfExternalFluxLowerEarth?: number | null;
  readonly whiteDwarfExternalFluxUpperEarth?: number | null;
  readonly whiteDwarfEquilibriumLowerKelvin?: number | null;
  readonly whiteDwarfEquilibriumUpperKelvin?: number | null;
  readonly whiteDwarfCompanionEnvelopeIncluded?: boolean;
  readonly whiteDwarfHasUnresolvedCompanion?: boolean;

  /** H4: WD-only/no-replenishment scenario, NOT a present-day atmosphere. */
  readonly whiteDwarfPostAgbAtmosphereScenario?: PostAgbAtmosphereScenario | null;
  /** H4b: parametric RGB/AGB/WD sensitivity, never an actual atmosphere. */
  readonly whiteDwarfPostAgbAtmosphereHistory?: WhiteDwarfPostAgbAtmosphereHistory | null;
  /** H4c: direct-envelope/escape/outgassing sensitivity, not present Ground Truth. */
  readonly whiteDwarfPostAgbSurvivalAssessment?: PostAgbPlanetarySurvivalAssessment | null;
  /** H4d: read-only distinction between canonical existence and historical hypotheses. */
  readonly whiteDwarfPostAgbEnvironmentalResolution?: WhiteDwarfPostAgbEnvironmentalResolution | null;
  /** H5: generated model state, NOT an observed/current-confirmed atmosphere. */
  readonly whiteDwarfPostAgbEvolvedEnvironment?: WhiteDwarfEvolvedEnvironment | null;
  readonly whiteDwarfPostAgbModeledCompanionFluxEarth?: number | null;

  /** 29.1E-e.1: current environment was recomputed while preserving orbital geometry provisionally. */
  readonly conditionalEnvironmentReassessmentApplied?: boolean;

  /** Thermal-equivalent forcing supplied to phase 20. It is not host luminosity. */
  readonly conditionalEnvironmentEffectiveInsolationEarth?: number | null;

  readonly conditionalEnvironmentUsesMinimumRadiativeFloor?: boolean;

  /** 29.1E-e.2 present-day intrinsic heat terms used only by the conditional thermal closure. */
  readonly conditionalGeothermalHeatFluxWattsPerSquareMeter?: number | null;
  readonly conditionalTidalHeatFluxWattsPerSquareMeter?: number | null;
  readonly conditionalTotalIntrinsicHeatFluxWattsPerSquareMeter?: number | null;
  readonly conditionalIntrinsicEquivalentInsolationEarth?: number | null;

  /** Intrinsic-only estimate when compact-host irradiation is NOT modeled.
   * NOT a present-day climate or atmosphere reassessment. */
  readonly intrinsicOnlyThermalProjectionApplied?: boolean;
  readonly intrinsicOnlyBlackbodyEquivalentKelvin?: number | null;


  /** 29.1E-g — deterministic current orbital state after realized stellar mass loss/SN events. */
  readonly postSupernovaOrbitDisposition?:
    'UNCHANGED' | 'BOUND_RECONFIGURED' | 'EJECTED' | 'HOST_DISRUPTED';
  readonly postSupernovaSourceEventKeys?: readonly string[];
  readonly postSupernovaSemiMajorAxisAu?: number | null;
  readonly postSupernovaEccentricity?: number | null;
  readonly postSupernovaPeriastronAu?: number | null;
  readonly postSupernovaApoastronAu?: number | null;
  readonly postSupernovaInclinationChangeDegrees?: number | null;
  readonly postSupernovaMassLossRegime?: 'NONE' | 'ADIABATIC' | 'TRANSITIONAL' | 'IMPULSIVE';
  readonly postSupernovaMaximumEffectiveKickKmS?: number;
  readonly postSupernovaMoonStates?: readonly Readonly<{
    moonOrdinal: number;
    survival: 'UNCHANGED' | 'BOUND' | 'LOST_FROM_HILL_SPHERE' | 'BOUND_TO_EJECTED_PLANET' | 'UNRESOLVED_HOST_DISRUPTION';
    survives: boolean | null;
    currentHillSphereRadiusPlanetRadii: number | null;
    progradeStableLimitPlanetRadii: number | null;
  }>[];
}

export interface PlanetScientificResolvedTarget {
  readonly identity:
    PlanetScientificIdentitySource;

  readonly detail:
    PlanetScientificDetailSource;

  /** 29.1E-e optional current-host correction for evolved V2 multihost systems. */
  readonly hostEvolution?:
    PlanetScientificHostEvolutionContext;
}

interface Phase18PlanetTarget {
  readonly identity:
    PlanetScientificIdentitySource;

  readonly planetarySystem:
    ReturnType<typeof PlanetarySystemGenerator.generate>;
}

/**
 * Point-26.3/26.4 deterministic resolver for one mature planet.
 *
 * `resolve(...)` preserves the point-26.3 identity-only contract and stops at
 * the frozen phase-18 planetary-system boundary. `resolveDetailed(...)` is the
 * point-26.4 extension: after the caller has enforced the CONFIRMED host-system
 * boundary, it materializes the already-frozen phase-19 Planet plus the phase-20
 * atmosphere/environment aggregate and phase-21 moon system exactly once.
 *
 * The returned detail payload is a safe primitive projection. Domain objects,
 * generation keys and procedural seeds are deliberately not returned to the UI.
 */
export class PlanetScientificTargetResolver {

  private constructor() {}

  static resolve(
    generationKey:
      UniverseGenerationKey,

    locator:
      BodyLocator,
  ): PlanetScientificIdentitySource | null {

    return resolvePhase18Target(
      generationKey,
      locator,
    )?.identity ??
      null;
  }

  static resolveDetailed(
    generationKey:
      UniverseGenerationKey,

    locator:
      BodyLocator,
  ): PlanetScientificResolvedTarget | null {

    const target =
      resolvePhase18Target(
        generationKey,
        locator,
      );

    if (
      target ===
        null
    ) {
      return null;
    }

    const planet =
      PlanetGenerator
        .generate(
          generationKey,
          target.planetarySystem,
          target.identity.locator,
        );

    const atmosphere =
      AtmosphereGenerator
        .generate(
          generationKey,
          planet,
        );

    const moonSystem =
      MoonGenerator
        .generate(
          generationKey,
          planet,
        );

    return this.projectGenerated(target.identity, planet, atmosphere, moonSystem);
  }

  /**
   * Shared scientific projection of an ALREADY materialized body. Neither the
   * multihost adapter nor this boundary regenerate physical properties.
   * The caller supplies a public identity whose locator can differ from the
   * private source planet locator; the source entities are never exposed.
   */
  static projectGenerated(
    identity: PlanetScientificIdentitySource,
    planet: ReturnType<typeof PlanetGenerator.generate>,
    atmosphere: ReturnType<typeof AtmosphereGenerator.generate>,
    moonSystem: ReturnType<typeof MoonGenerator.generate>,
  ): PlanetScientificResolvedTarget {
    if (atmosphere.hostPlanet !== planet || moonSystem.hostPlanet !== planet) {
      throw new Error('Scientific projection must receive one consistent generated planet.');
    }
    return Object.freeze({
      identity,
      detail:
        Object.freeze({
          general:
            Object.freeze({
              planetType:
                planet.planetType,
              massEarth:
                planet.massEarth,
              radiusEarth:
                planet.radiusEarth,
              densityGramsPerCubicCentimeter:
                planet.densityGramsPerCubicCentimeter,
              surfaceGravityEarth:
                planet.surfaceGravityEarth,
              surfaceGravityMetersPerSecondSquared:
                planet.surfaceGravityMetersPerSecondSquared,
              rotationPeriodHours:
                planet.rotationPeriodHours,
              dayLengthHours:
                planet.dayLengthHours,
              axialTiltDegrees:
                planet.axialTiltDegrees,
              isRetrogradeRotation:
                planet.isRetrogradeRotation,
              isTidallySynchronized:
                planet.isTidallySynchronized,
              referenceBondAlbedo01:
                planet.referenceBondAlbedo01,
              isTypePhysicallyCoherent:
                planet.isTypePhysicallyCoherent,
              metallicCoreMassFraction01:
                planet.internalComposition.metallicCoreMassFraction01,
              silicateInteriorMassFraction01:
                planet.internalComposition.silicateInteriorMassFraction01,
              condensedIceMassFraction01:
                planet.internalComposition.condensedIceMassFraction01,
              volatileRichInteriorMassFraction01:
                planet.internalComposition.volatileRichInteriorMassFraction01,
              gaseousEnvelopeMassFraction01:
                planet.internalComposition.gaseousEnvelopeMassFraction01,
            }),
          orbit:
            Object.freeze({
              semiMajorAxisAu:
                planet.orbit.semiMajorAxisAu,
              eccentricity:
                planet.orbit.eccentricity,
              inclinationDegrees:
                planet.orbit.inclinationDegrees,
              periastronAu:
                planet.orbit.periastronAu,
              apoastronAu:
                planet.orbit.apoastronAu,
              periodDays:
                planet.orbitalPeriod.periodDays,
              periodYears:
                planet.orbitalPeriod.periodYears,
              radiativeHabitableZoneRelation:
                planet.habitableZoneClassification.radiativeRelation,
              dynamicallyAvailableHabitableZoneRelation:
                planet.habitableZoneClassification.dynamicallyAvailableRelation,
              referenceMeanInsolationEarth:
                planet.typeClassification.referenceMeanInsolationEarth,
              tidalHeatingProxy:
                planet.typeClassification.tidalHeatingProxy,
            }),
          surface:
            Object.freeze({
              surfaceBaseRegime:
                planet.surfaceBaseRegime,
              hasDefinedSolidSurfaceBase:
                planet.hasDefinedSolidSurfaceBase,
              baseSolidSurfaceRoughness01:
                planet.baseSolidSurfaceRoughness01,
              waterInventoryIndex01:
                atmosphere.waterInventoryIndex01,
              waterPhaseRegime:
                atmosphere.waterPhaseRegime,
              surfaceWaterRegime:
                atmosphere.surfaceWaterRegime,
              waterIceFraction01:
                atmosphere.waterIceFraction01,
              waterLiquidFraction01:
                atmosphere.waterLiquidFraction01,
              waterVaporFraction01:
                atmosphere.waterVaporFraction01,
              surfaceIceCoverageFraction01:
                atmosphere.surfaceIceCoverageFraction01,
              surfaceLiquidWaterCoverageFraction01:
                atmosphere.surfaceLiquidWaterCoverageFraction01,
              hasPersistentSurfaceLiquidWater:
                atmosphere.hasPersistentSurfaceLiquidWater,
              surfaceRadiationRegime:
                atmosphere.surfaceRadiationRegime,
              surfaceRadiationProtectionRegime:
                atmosphere.surfaceRadiationProtectionRegime,
              surfaceRadiationExposureIndex01:
                atmosphere.surfaceRadiationExposureIndex01,
              surfaceRadiationProtectionIndex01:
                atmosphere.surfaceRadiationProtectionIndex01,
              hasEffectiveSurfaceRadiationProtection:
                atmosphere.hasEffectiveSurfaceRadiationProtection,
            }),
          atmosphere:
            Object.freeze({
              pressureRegime:
                atmosphere.pressureRegime,
              retainedPressureRegime:
                atmosphere.retainedPressureRegime,
              retainedSurfacePressurePascal:
                atmosphere.retainedSurfacePressurePascal,
              retentionRegime:
                atmosphere.retentionRegime,
              atmosphericInventoryRetentionFraction01:
                atmosphere.atmosphericInventoryRetentionFraction01,
              retainedReferenceDensityKilogramsPerCubicMeter:
                atmosphere.retainedReferenceDensityKilogramsPerCubicMeter,
              retainedMeanMolarMassGramsPerMole:
                atmosphere.retainedMeanMolarMassGramsPerMole,
              greenhouseRegime:
                atmosphere.greenhouseRegime,
              longwaveTrappingFraction01:
                atmosphere.longwaveTrappingFraction01,
              isVacuum:
                atmosphere.isVacuum,
              isDeepEnvelope:
                atmosphere.isDeepEnvelope,
              retainedGasComposition:
                Object.freeze(
                  atmosphere
                    .retainedGasComposition
                    .map(
                      component =>
                        Object.freeze({
                          gas:
                            component.gas,
                          moleFraction01:
                            component.moleFraction01,
                        }),
                    ),
                ),
            }),
          climate:
            Object.freeze({
              equilibriumTemperatureKelvin:
                atmosphere.equilibriumTemperatureKelvin,
              meanSurfaceTemperatureKelvin:
                atmosphere.meanSurfaceTemperatureKelvin,
              greenhouseSurfaceWarmingKelvin:
                atmosphere.greenhouseSurfaceWarmingKelvin,
              climateStabilityRegime:
                atmosphere.climateStabilityRegime,
              climateStabilityIndex01:
                atmosphere.climateStabilityIndex01,
              seasonalTemperatureAmplitudeKelvin:
                atmosphere.seasonalTemperatureAmplitudeKelvin,
              diurnalTemperatureRangeKelvin:
                atmosphere.diurnalTemperatureRangeKelvin,
              minimumSurfaceTemperatureKelvin:
                atmosphere.minimumSurfaceTemperatureKelvin,
              maximumSurfaceTemperatureKelvin:
                atmosphere.maximumSurfaceTemperatureKelvin,
              heatRedistributionEfficiency01:
                atmosphere.heatRedistributionEfficiency01,
            }),
          geology:
            Object.freeze({
              geologyRegime:
                atmosphere.geologyRegime,
              volcanismRegime:
                atmosphere.volcanismRegime,
              tectonicRegime:
                atmosphere.tectonicRegime,
              internalHeatRetentionIndex01:
                atmosphere.internalHeatRetentionIndex01,
              tidalHeatingIndex01:
                atmosphere.tidalHeatingIndex01,
              geologicalActivityIndex01:
                atmosphere.geologicalActivityIndex01,
              volcanismIndex01:
                atmosphere.volcanismIndex01,
              tectonicMobilityIndex01:
                atmosphere.tectonicMobilityIndex01,
              volatileOutgassingPotential01:
                atmosphere.volatileOutgassingPotential01,
              surfaceRenewalPotential01:
                atmosphere.surfaceRenewalPotential01,
              isGeologicallyActive:
                atmosphere.isGeologicallyActive,
              magneticFieldRegime:
                atmosphere.magneticFieldRegime,
              magnetosphereRegime:
                atmosphere.magnetosphereRegime,
              dynamoPotentialIndex01:
                atmosphere.dynamoPotentialIndex01,
              intrinsicMagneticFieldIndex01:
                atmosphere.intrinsicMagneticFieldIndex01,
              magnetosphericProtectionIndex01:
                atmosphere.magnetosphericProtectionIndex01,
              hasSustainedDynamo:
                atmosphere.hasSustainedDynamo,
            }),
          moons:
            Object.freeze({
              moonCount:
                moonSystem.moonCount,
              relevantMoonCount:
                moonSystem.relevantMoonCount,
              unmaterializedMinorMoonCount:
                moonSystem.unmaterializedMinorMoonCount,
              potentiallyHabitableMoonCount:
                moonSystem.potentiallyHabitableMoonCount,
              surfaceHabitabilityCandidateCount:
                moonSystem.surfaceHabitabilityCandidateCount,
              subsurfaceHabitabilityCandidateCount:
                moonSystem.subsurfaceHabitabilityCandidateCount,
              relevantMoons:
                Object.freeze(
                  moonSystem
                    .relevantMoons
                    .map(
                      moon =>
                        Object.freeze({
                          designation:
                            moon.name,
                          moonOrdinal:
                            moon.moonOrdinal,
                          moonIndex:
                            moon.moonOrdinal - 1,
                          massEarth:
                            moon.massEarth,
                          radiusEarth:
                            moon.radiusEarth,
                          meanDensityGramsPerCubicCentimeter:
                            moon.meanDensityGramsPerCubicCentimeter,
                          surfaceGravityEarth:
                            moon.surfaceGravityEarth,
                          semiMajorAxisPlanetRadii:
                            moon.semiMajorAxisPlanetRadii,
                          semiMajorAxisKilometers:
                            moon.orbit.semiMajorAxisKilometers,
                          eccentricity:
                            moon.orbit.eccentricity,
                          inclinationDegrees:
                            moon.orbit.inclinationDegrees,
                          orbitalPeriodDays:
                            moon.orbitalPeriodDays,
                          rocheLimitPlanetRadii:
                            moon.orbit.rocheLimitPlanetRadii,
                          hillSphereRadiusPlanetRadii:
                            moon.orbit.sourceHillSphereRadiusPlanetRadii,
                          synchronousOrbitPlanetRadii:
                            moon.tidalState.synchronousOrbitPlanetRadii,
                          tidalForcingIndex01:
                            moon.tidalState.tidalForcingIndex01,
                          tidalHeatingIndex01:
                            moon.tidalHeatingIndex01,
                          tidalRegime:
                            moon.tidalState.tidalRegime,
                          tidalLockingIndex01:
                            moon.tidalLockingIndex01,
                          tidalLockingRegime:
                            moon.tidalState.tidalLockingRegime,
                          rotationPeriodHours:
                            moon.rotationPeriodHours,
                          migrationRegime:
                            moon.tidalState.migrationRegime,
                          isTidallyLocked:
                            moon.isTidallyLocked,
                          referenceMeanInsolationEarth:
                            moon.environmentState.sourceReferenceMeanInsolationEarth,
                          inferredIceRichnessIndex01:
                            moon.environmentState.inferredIceRichnessIndex01,
                          inferredBondAlbedo01:
                            moon.environmentState.inferredBondAlbedo01,
                          equilibriumTemperatureKelvin:
                            moon.environmentState.equilibriumTemperatureKelvin,
                          estimatedSurfaceTemperatureKelvin:
                            moon.environmentState.estimatedSurfaceTemperatureKelvin,
                          atmosphereRetentionIndex01:
                            moon.environmentState.atmosphereRetentionIndex01,
                          atmosphereRegime:
                            moon.atmosphereRegime,
                          waterInventoryIndex01:
                            moon.environmentState.waterInventoryIndex01,
                          subsurfaceOceanPotentialIndex01:
                            moon.environmentState.subsurfaceOceanPotentialIndex01,
                          surfaceLiquidWaterPotentialIndex01:
                            moon.environmentState.surfaceLiquidWaterPotentialIndex01,
                          waterRegime:
                            moon.waterRegime,
                          internalHeatRetentionIndex01:
                            moon.environmentState.internalHeatRetentionIndex01,
                          geologicalActivityIndex01:
                            moon.environmentState.geologicalActivityIndex01,
                          geologyRegime:
                            moon.geologyRegime,
                          hasAtmosphere:
                            moon.hasAtmosphere,
                          hasWater:
                            moon.hasWater,
                          hasSubsurfaceOcean:
                            moon.hasSubsurfaceOcean,
                          hasSurfaceLiquidWater:
                            moon.hasSurfaceLiquidWater,
                          isGeologicallyActive:
                            moon.isGeologicallyActive,
                          surfaceTemperatureSupportIndex01:
                            moon.habitabilityState.surfaceTemperatureSupportIndex01,
                          surfaceAtmosphereSupportIndex01:
                            moon.habitabilityState.surfaceAtmosphereSupportIndex01,
                          surfaceGravitySupportIndex01:
                            moon.habitabilityState.surfaceGravitySupportIndex01,
                          tidalModerationIndex01:
                            moon.habitabilityState.tidalModerationIndex01,
                          subsurfaceEnergySupportIndex01:
                            moon.habitabilityState.subsurfaceEnergySupportIndex01,
                          surfaceHabitabilityIndex01:
                            moon.habitabilityState.surfaceHabitabilityIndex01,
                          subsurfaceHabitabilityIndex01:
                            moon.habitabilityState.subsurfaceHabitabilityIndex01,
                          overallHabitabilityIndex01:
                            moon.overallHabitabilityIndex01,
                          surfaceHabitabilityCandidate:
                            moon.supportsPotentialSurfaceHabitability,
                          subsurfaceHabitabilityCandidate:
                            moon.supportsPotentialSubsurfaceHabitability,
                          habitabilityRegime:
                            moon.habitabilityRegime,
                          isPotentiallyHabitable:
                            moon.isPotentiallyHabitable,
                          giantHostSpecialization:
                            moon.hasGiantHostSpecialization,
                          giantMoonOrbitalFamily:
                            moon.giantMoonState.orbitalFamily,
                          giantMoonCompositionRegime:
                            moon.giantMoonState.compositionRegime,
                          isLargeGiantMoon:
                            moon.giantMoonState.isLargeMoon,
                          isTidallyActiveGiantMoon:
                            moon.giantMoonState.isTidallyActive,
                          isOceanBearingGiantMoonCandidate:
                            moon.giantMoonState.isOceanBearingCandidate,
                        }),
                    ),
                ),
            }),
        }),
    });
  }

  /**
   * 29.1E-e.2 replaces only environment-dependent projections with a conditional
   * present-day reassessment. Identity, bulk planet physics, orbit geometry,
   * moon population/orbits and intrinsic tidal/geological source terms remain
   * the already-generated values.
   */
  static applyConditionalEnvironmentReassessment(
    target: PlanetScientificResolvedTarget,
    reassessment: PostRemnantConditionalEnvironmentReassessment,
  ): PlanetScientificResolvedTarget {
    const atmosphere = reassessment.atmosphere;
    const moonByOrdinal = new Map(
      reassessment.moonEnvironments.map(moon => [moon.moonOrdinal, moon] as const),
    );
    const relevantMoons = Object.freeze(
      target.detail.moons.relevantMoons.map(moon => {
        const current = moonByOrdinal.get(moon.moonOrdinal);
        if (current === undefined) return moon;
        const environment = current.environmentState;
        const habitability = current.habitabilityState;
        return Object.freeze({
          ...moon,
          referenceMeanInsolationEarth: environment.sourceReferenceMeanInsolationEarth,
          inferredIceRichnessIndex01: environment.inferredIceRichnessIndex01,
          inferredBondAlbedo01: environment.inferredBondAlbedo01,
          equilibriumTemperatureKelvin: environment.equilibriumTemperatureKelvin,
          estimatedSurfaceTemperatureKelvin: environment.estimatedSurfaceTemperatureKelvin,
          atmosphereRetentionIndex01: environment.atmosphereRetentionIndex01,
          atmosphereRegime: environment.atmosphereRegime,
          waterInventoryIndex01: environment.waterInventoryIndex01,
          subsurfaceOceanPotentialIndex01: environment.subsurfaceOceanPotentialIndex01,
          surfaceLiquidWaterPotentialIndex01: environment.surfaceLiquidWaterPotentialIndex01,
          waterRegime: environment.waterRegime,
          internalHeatRetentionIndex01: environment.internalHeatRetentionIndex01,
          geologicalActivityIndex01: environment.geologicalActivityIndex01,
          geologyRegime: environment.geologyRegime,
          hasAtmosphere: environment.hasAtmosphere,
          hasWater: environment.hasWater,
          hasSubsurfaceOcean: environment.hasSubsurfaceOcean,
          hasSurfaceLiquidWater: environment.hasSurfaceLiquidWater,
          isGeologicallyActive: environment.isGeologicallyActive,
          surfaceTemperatureSupportIndex01: habitability.surfaceTemperatureSupportIndex01,
          surfaceAtmosphereSupportIndex01: habitability.surfaceAtmosphereSupportIndex01,
          surfaceGravitySupportIndex01: habitability.surfaceGravitySupportIndex01,
          tidalModerationIndex01: habitability.tidalModerationIndex01,
          subsurfaceEnergySupportIndex01: habitability.subsurfaceEnergySupportIndex01,
          surfaceHabitabilityIndex01: habitability.surfaceHabitabilityIndex01,
          subsurfaceHabitabilityIndex01: habitability.subsurfaceHabitabilityIndex01,
          overallHabitabilityIndex01: habitability.overallHabitabilityIndex01,
          surfaceHabitabilityCandidate: habitability.supportsPotentialSurfaceHabitability,
          subsurfaceHabitabilityCandidate: habitability.supportsPotentialSubsurfaceHabitability,
          habitabilityRegime: habitability.habitabilityRegime,
          isPotentiallyHabitable: habitability.isPotentiallyHabitable,
        });
      }),
    );
    const potentiallyHabitableMoonCount = relevantMoons.filter(m => m.isPotentiallyHabitable).length;
    const surfaceHabitabilityCandidateCount = relevantMoons.filter(m => m.surfaceHabitabilityCandidate).length;
    const subsurfaceHabitabilityCandidateCount = relevantMoons.filter(m => m.subsurfaceHabitabilityCandidate).length;

    return Object.freeze({
      ...target,
      detail: Object.freeze({
        ...target.detail,
        surface: Object.freeze({
          ...target.detail.surface,
          waterInventoryIndex01: atmosphere.waterInventoryIndex01,
          waterPhaseRegime: atmosphere.waterPhaseRegime,
          surfaceWaterRegime: atmosphere.surfaceWaterRegime,
          waterIceFraction01: atmosphere.waterIceFraction01,
          waterLiquidFraction01: atmosphere.waterLiquidFraction01,
          waterVaporFraction01: atmosphere.waterVaporFraction01,
          surfaceIceCoverageFraction01: atmosphere.surfaceIceCoverageFraction01,
          surfaceLiquidWaterCoverageFraction01: atmosphere.surfaceLiquidWaterCoverageFraction01,
          hasPersistentSurfaceLiquidWater: atmosphere.hasPersistentSurfaceLiquidWater,
          surfaceRadiationRegime: atmosphere.surfaceRadiationRegime,
          surfaceRadiationProtectionRegime: atmosphere.surfaceRadiationProtectionRegime,
          surfaceRadiationExposureIndex01: atmosphere.surfaceRadiationExposureIndex01,
          surfaceRadiationProtectionIndex01: atmosphere.surfaceRadiationProtectionIndex01,
          hasEffectiveSurfaceRadiationProtection: atmosphere.hasEffectiveSurfaceRadiationProtection,
        }),
        atmosphere: Object.freeze({
          pressureRegime: atmosphere.pressureRegime,
          retainedPressureRegime: atmosphere.retainedPressureRegime,
          retainedSurfacePressurePascal: atmosphere.retainedSurfacePressurePascal,
          retentionRegime: atmosphere.retentionRegime,
          atmosphericInventoryRetentionFraction01: atmosphere.atmosphericInventoryRetentionFraction01,
          retainedReferenceDensityKilogramsPerCubicMeter: atmosphere.retainedReferenceDensityKilogramsPerCubicMeter,
          currentDensityKilogramsPerCubicMeter:
            reassessment.currentAtmosphericDensityKilogramsPerCubicMeter,
          retainedMeanMolarMassGramsPerMole: atmosphere.retainedMeanMolarMassGramsPerMole,
          greenhouseRegime: atmosphere.greenhouseRegime,
          longwaveTrappingFraction01: atmosphere.longwaveTrappingFraction01,
          isVacuum: atmosphere.isVacuum,
          isDeepEnvelope: atmosphere.isDeepEnvelope,
          retainedGasComposition: Object.freeze(atmosphere.retainedGasComposition.map(component => Object.freeze({
            gas: component.gas,
            moleFraction01: component.moleFraction01,
          }))),
        }),
        climate: Object.freeze({
          equilibriumTemperatureKelvin: atmosphere.equilibriumTemperatureKelvin,
          meanSurfaceTemperatureKelvin: atmosphere.meanSurfaceTemperatureKelvin,
          greenhouseSurfaceWarmingKelvin: atmosphere.greenhouseSurfaceWarmingKelvin,
          climateStabilityRegime: atmosphere.climateStabilityRegime,
          climateStabilityIndex01: atmosphere.climateStabilityIndex01,
          seasonalTemperatureAmplitudeKelvin: atmosphere.seasonalTemperatureAmplitudeKelvin,
          diurnalTemperatureRangeKelvin: atmosphere.diurnalTemperatureRangeKelvin,
          minimumSurfaceTemperatureKelvin: atmosphere.minimumSurfaceTemperatureKelvin,
          maximumSurfaceTemperatureKelvin: atmosphere.maximumSurfaceTemperatureKelvin,
          heatRedistributionEfficiency01: atmosphere.heatRedistributionEfficiency01,
        }),
        geology: Object.freeze({
          ...target.detail.geology,
          geologyRegime: atmosphere.geologyRegime,
          volcanismRegime: atmosphere.volcanismRegime,
          tectonicRegime: atmosphere.tectonicRegime,
          internalHeatRetentionIndex01: atmosphere.internalHeatRetentionIndex01,
          tidalHeatingIndex01: atmosphere.tidalHeatingIndex01,
          geologicalActivityIndex01: atmosphere.geologicalActivityIndex01,
          volcanismIndex01: atmosphere.volcanismIndex01,
          tectonicMobilityIndex01: atmosphere.tectonicMobilityIndex01,
          volatileOutgassingPotential01: atmosphere.volatileOutgassingPotential01,
          surfaceRenewalPotential01: atmosphere.surfaceRenewalPotential01,
          isGeologicallyActive: atmosphere.isGeologicallyActive,
          magneticFieldRegime: atmosphere.magneticFieldRegime,
          magnetosphereRegime: atmosphere.magnetosphereRegime,
          dynamoPotentialIndex01: atmosphere.dynamoPotentialIndex01,
          intrinsicMagneticFieldIndex01: atmosphere.intrinsicMagneticFieldIndex01,
          magnetosphericProtectionIndex01: atmosphere.magnetosphericProtectionIndex01,
          hasSustainedDynamo: atmosphere.hasSustainedDynamo,
        }),
        moons: Object.freeze({
          ...target.detail.moons,
          potentiallyHabitableMoonCount,
          surfaceHabitabilityCandidateCount,
          subsurfaceHabitabilityCandidateCount,
          relevantMoons,
        }),
      }),
    });
  }
}

function resolvePhase18Target(
  generationKey:
    UniverseGenerationKey,

  locator:
    BodyLocator,
): Phase18PlanetTarget | null {

  const systemLocator =
    new SystemLocator(
      locator.galaxyIndex,
      locator.sectorKey,
      locator.galacticObjectIndex,
    );

  const galaxy =
    GalaxyGenerator.generate(
      generationKey,
      systemLocator.galaxyIndex,
    );

  const grid =
    GalaxySectorGridGenerator
      .generate(
        galaxy,
      );

  const stellarDensity =
    GalaxySectorStellarDensityGenerator
      .generate(
        galaxy,
        grid,
        GalaxySectorKeyCodec
          .decode(
            systemLocator.sectorKey,
          ),
      );

  const stellarPopulation =
    GalaxySectorStellarPopulationPropertiesGenerator
      .generate(
        galaxy,
        stellarDensity,
      );

  const stellarPopulationProfile =
    StellarPopulationProfileGenerator
      .generate(
        generationKey,
        galaxy.physicalProperties,
        stellarPopulation,
      );

  const stellarSystem =
    StellarSystemGenerator
      .generate(
        generationKey,
        systemLocator,
        stellarPopulation,
        stellarPopulationProfile,
      );

  const formationSnapshot =
    ProtoplanetaryFormationSnapshotGenerator
      .generateMaturationReferenceOrNull(
        generationKey,
        systemLocator,
      );

  if (
    formationSnapshot ===
      null
  ) {
    return null;
  }

  const formationBlueprint =
    PlanetaryFormationMaturationGenerator
      .generate(
        generationKey,
        formationSnapshot.systemSeed,
        formationSnapshot.diskProfile,
        formationSnapshot.diskStructure,
        formationSnapshot.planetFormationProfile,
        formationSnapshot.candidatePopulation,
        formationSnapshot.earlyDynamics,
      );

  const planetarySystem =
    PlanetarySystemGenerator
      .generate(
        generationKey,
        stellarSystem,
        formationBlueprint,
      );

  if (
    locator.bodyIndex <
      0n ||
    locator.bodyIndex >=
      BigInt(
        planetarySystem
          .planetCount,
      )
  ) {
    return null;
  }

  const index =
    Number(
      locator.bodyIndex,
    );

  const slot =
    planetarySystem
      .planetSlots[index];

  const designation =
    planetarySystem
      .planetDesignations[index];

  if (
    slot ===
      undefined ||
    designation ===
      undefined ||
    slot.bodyLocator.bodyIndex !==
      locator.bodyIndex
  ) {
    return null;
  }

  return Object.freeze({
    identity:
      Object.freeze({
        locator:
          slot.bodyLocator,
        planetOrdinal:
          slot.planetOrdinal,
        designation:
          designation.name,
        hostSystemDesignation:
          stellarSystem.designation.name,
        orbitTopology:
          planetarySystem
            .architecture
            .orbitTopology,
        hostPlanetCount:
          planetarySystem
            .planetCount,
      }),
    planetarySystem,
  });
}
