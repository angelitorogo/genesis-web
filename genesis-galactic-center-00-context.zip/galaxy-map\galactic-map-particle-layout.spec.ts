import {
  DiscoveryState,
} from '../../domain/discovery/discovery-state';

import {
  GeneratorVersion,
} from '../../domain/generation/generator-version';

import {
  UniverseGenerationKey,
} from '../../domain/generation/universe-generation-key';

import {
  UniverseSeed,
} from '../../domain/universe/universe-seed';

import {
  ExternalGalaxyPreliminaryInformationGenerator,
} from '../../simulation/observation/galaxy/external-galaxy-preliminary-information-generator';

import {
  GalaxyGenerator,
} from '../../simulation/universe/galaxy-generator';

import {
  GalaxyVisualStructureGenerator,
} from '../../simulation/universe/galaxy-visual-structure-generator';

import {
  GalacticMapModel,
} from './galactic-map-model';

import {
  GalacticMapParticleLayoutGenerator,
  type GalacticMapParticleLayout,
} from './galactic-map-particle-layout';

import {
  createGalacticMapParticleRenderInput,
} from './galactic-map-particle-render-input';

import {
  DWARF_BODY_PARTICLE_COUNT,
  DWARF_CLUSTER_PARTICLE_COUNT,
  DWARF_CORE_PARTICLE_COUNT,
  DWARF_GAS_PARTICLE_COUNT,
  DWARF_TOTAL_PARTICLE_COUNT,
} from './dwarf-galaxy-particle-layout';

import {
  IRREGULAR_BODY_PARTICLE_COUNT,
  IRREGULAR_CLUSTER_PARTICLE_COUNT,
  IRREGULAR_CORE_PARTICLE_COUNT,
  IRREGULAR_GAS_PARTICLE_COUNT,
  IRREGULAR_TOTAL_PARTICLE_COUNT,
} from './irregular-galaxy-particle-layout';

const CORE_PARTICLE_COUNT =
  20_000;

const BODY_PARTICLE_COUNT =
  92_000;

const ELLIPTICAL_PARTICLE_COUNT =
  124_000;

const SPIRAL_STELLAR_PARTICLE_COUNT =
  196_000;

const SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT =
  16_000;

const SPIRAL_PARTICLE_COUNT =
  SPIRAL_STELLAR_PARTICLE_COUNT +
  SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT;

const BARRED_SPIRAL_PARTICLE_COUNT =
  282_000;

const BARRED_SPIRAL_BODY_PARTICLE_COUNT =
  154_000;

const BARRED_SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT =
  72_000;

const BARRED_SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT =
  16_000;

const BAR_PARTICLE_COUNT =
  8_000;

const SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT =
  72_000;


const DWARF_PARTICLE_COUNT =
  DWARF_TOTAL_PARTICLE_COUNT;

const IRREGULAR_PARTICLE_COUNT =
  IRREGULAR_TOTAL_PARTICLE_COUNT;

describe(
  'GalacticMapParticleLayoutGenerator',
  () => {
    const generationKey =
      new UniverseGenerationKey(
        UniverseSeed.parse(
          '7F21-A9D4-18CE-4B70-92F1-6A0C-6E35-D8B1',
        ),
        GeneratorVersion.V1,
      );

    function model(
      galaxyIndex:
        bigint,
    ): GalacticMapModel {

      const galaxy =
        GalaxyGenerator.generate(
          generationKey,
          galaxyIndex,
        );

      return new GalacticMapModel(
        generationKey,
        galaxyIndex,
        ExternalGalaxyPreliminaryInformationGenerator
          .generate(
            generationKey,
            galaxyIndex,
            DiscoveryState.DISCOVERED,
          ),
        GalaxyVisualStructureGenerator
          .generate(
            galaxy,
          ),
        galaxy.type,
      );
    }

    it(
      'should generate exactly the same GPU buffers for the same galactic map model',
      () => {
        const target =
          model(
            0n,
          );

        const first =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const second =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        expect(
          second.count,
        ).toBe(
          first.count,
        );

        expect(
          second.positions,
        ).toEqual(
          first.positions,
        );

        expect(
          second.colors,
        ).toEqual(
          first.colors,
        );

        expect(
          second.sizes,
        ).toEqual(
          first.sizes,
        );

        expect(
          second.opacities,
        ).toEqual(
          first.opacities,
        );
      },30_000,
    );

    it(
      'should preserve exact frozen GPU buffers when the same render input is structured-clone safe for point-10.9',
      () => {
        const target =
          model(
            0n,
          );

        const synchronous =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const workerInput =
          structuredClone(
            createGalacticMapParticleRenderInput(
              target,
            ),
          );

        const workerEquivalent =
          GalacticMapParticleLayoutGenerator
            .generateFromRenderInput(
              workerInput,
            );

        expect(
          workerEquivalent.count,
        ).toBe(
          synchronous.count,
        );

        expect(
          workerEquivalent.positions,
        ).toEqual(
          synchronous.positions,
        );

        expect(
          workerEquivalent.colors,
        ).toEqual(
          synchronous.colors,
        );

        expect(
          workerEquivalent.sizes,
        ).toEqual(
          synchronous.sizes,
        );

        expect(
          workerEquivalent.opacities,
        ).toEqual(
          synchronous.opacities,
        );
      },
      30_000,
    );


    it(
      'should preserve the dedicated BARRED_SPIRAL renderer across the structured-clone Web Worker boundary',
      () => {
        const target =
          model(
            1n,
          );

        const synchronous =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const workerInput =
          structuredClone(
            createGalacticMapParticleRenderInput(
              target,
            ),
          );

        const workerEquivalent =
          GalacticMapParticleLayoutGenerator
            .generateFromRenderInput(
              workerInput,
            );

        expect(
          synchronous.count,
        ).toBe(
          BARRED_SPIRAL_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.count,
        ).toBe(
          BARRED_SPIRAL_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.positions,
        ).toEqual(
          synchronous.positions,
        );

        expect(
          workerEquivalent.colors,
        ).toEqual(
          synchronous.colors,
        );

        expect(
          workerEquivalent.sizes,
        ).toEqual(
          synchronous.sizes,
        );

        expect(
          workerEquivalent.opacities,
        ).toEqual(
          synchronous.opacities,
        );
      },
      30_000,
    );

    it(
      'should preserve the SPIRAL stellar and volumetric-gas enrichment across the structured-clone Web Worker boundary',
      () => {
        const target =
          model(
            3n,
          );

        const synchronous =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const workerInput =
          structuredClone(
            createGalacticMapParticleRenderInput(
              target,
            ),
          );

        const workerEquivalent =
          GalacticMapParticleLayoutGenerator
            .generateFromRenderInput(
              workerInput,
            );

        expect(
          synchronous.count,
        ).toBe(
          SPIRAL_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.count,
        ).toBe(
          SPIRAL_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.positions,
        ).toEqual(
          synchronous.positions,
        );

        expect(
          workerEquivalent.colors,
        ).toEqual(
          synchronous.colors,
        );

        expect(
          workerEquivalent.sizes,
        ).toEqual(
          synchronous.sizes,
        );

        expect(
          workerEquivalent.opacities,
        ).toEqual(
          synchronous.opacities,
        );
      },
      30_000,
    );


    it(
      'should preserve the dedicated DWARF renderer across the structured-clone Web Worker boundary',
      () => {
        const target =
          model(
            4n,
          );

        const synchronous =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const workerInput =
          structuredClone(
            createGalacticMapParticleRenderInput(
              target,
            ),
          );

        const workerEquivalent =
          GalacticMapParticleLayoutGenerator
            .generateFromRenderInput(
              workerInput,
            );

        expect(
          synchronous.count,
        ).toBe(
          DWARF_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.count,
        ).toBe(
          DWARF_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.positions,
        ).toEqual(
          synchronous.positions,
        );

        expect(
          workerEquivalent.colors,
        ).toEqual(
          synchronous.colors,
        );

        expect(
          workerEquivalent.sizes,
        ).toEqual(
          synchronous.sizes,
        );

        expect(
          workerEquivalent.opacities,
        ).toEqual(
          synchronous.opacities,
        );
      },
      30_000,
    );

    it(
      'should preserve the dedicated IRREGULAR renderer across the structured-clone Web Worker boundary',
      () => {
        const target =
          model(
            10n,
          );

        const synchronous =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const workerInput =
          structuredClone(
            createGalacticMapParticleRenderInput(
              target,
            ),
          );

        const workerEquivalent =
          GalacticMapParticleLayoutGenerator
            .generateFromRenderInput(
              workerInput,
            );

        expect(
          synchronous.count,
        ).toBe(
          IRREGULAR_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.count,
        ).toBe(
          IRREGULAR_PARTICLE_COUNT,
        );

        expect(
          workerEquivalent.positions,
        ).toEqual(
          synchronous.positions,
        );

        expect(
          workerEquivalent.colors,
        ).toEqual(
          synchronous.colors,
        );

        expect(
          workerEquivalent.sizes,
        ).toEqual(
          synchronous.sizes,
        );

        expect(
          workerEquivalent.opacities,
        ).toEqual(
          synchronous.opacities,
        );
      },
      30_000,
    );

    it(
      'should create the denser point-10.1 visual field without materializing star entities',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                0n,
              ),
            );

        expect(
          layout.count,
        ).toBe(
          ELLIPTICAL_PARTICLE_COUNT,
        );

        expect(
          layout.positions,
        ).toHaveLength(
          layout.count *
          3,
        );

        expect(
          layout.colors,
        ).toHaveLength(
          layout.count *
          3,
        );

        expect(
          layout.sizes,
        ).toHaveLength(
          layout.count,
        );

        expect(
          layout.opacities,
        ).toHaveLength(
          layout.count,
        );
      },
    );

    it(
      'should keep morphology-specific stellar budgets after SPIRAL moves gas and dust to continuous scene overlays',
      () => {
        const ellipticalModel =
          model(
            0n,
          );

        const barredModel =
          model(
            1n,
          );

        const spiralModel =
          model(
            3n,
          );

        const elliptical =
          GalacticMapParticleLayoutGenerator
            .generate(
              ellipticalModel,
            );

        const barred =
          GalacticMapParticleLayoutGenerator
            .generate(
              barredModel,
            );

        const spiral =
          GalacticMapParticleLayoutGenerator
            .generate(
              spiralModel,
            );

        expect(
          elliptical.count,
        ).toBe(
          ELLIPTICAL_PARTICLE_COUNT,
        );

        expect(
          barred.count,
        ).toBe(
          BARRED_SPIRAL_PARTICLE_COUNT,
        );

        expect(
          spiral.count,
        ).toBe(
          SPIRAL_PARTICLE_COUNT,
        );

        expect(
          spiral.count,
        ).toBeLessThan(
          barred.count,
        );

        expect(
          spiral.count,
        ).toBeGreaterThan(
          ELLIPTICAL_PARTICLE_COUNT,
        );

        expect(
          barredModel
            .visualStructure
            ?.bar,
        ).not.toBeNull();

        expect(
          spiralModel
            .visualStructure
            ?.bar,
        ).toBeNull();
      },
    );

    it(
      'should surround the elliptical family with a warm diffuse gaseous halo while preserving the stellar spheroid',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                0n,
              ),
            );

        const bodyStart =
          CORE_PARTICLE_COUNT;

        const bodyEnd =
          CORE_PARTICLE_COUNT +
          BODY_PARTICLE_COUNT;

        const haloStart =
          bodyEnd;

        const haloEnd =
          ELLIPTICAL_PARTICLE_COUNT;

        expect(
          projectedRadialReach(
            layout,
            haloStart,
            haloEnd,
          ),
        ).toBeGreaterThan(
          1.10,
        );

        expect(
          averageColorChannel(
            layout,
            haloStart,
            haloEnd,
            0,
          ),
        ).toBeGreaterThan(
          averageColorChannel(
            layout,
            haloStart,
            haloEnd,
            2,
          ) +
          0.08,
        );

        expect(
          averageValue(
            layout.sizes,
            haloStart,
            haloEnd,
          ),
        ).toBeGreaterThan(
          averageValue(
            layout.sizes,
            bodyStart,
            bodyEnd,
          ) *
          3.0,
        );

        expect(
          averageValue(
            layout.opacities,
            haloStart,
            haloEnd,
          ),
        ).toBeLessThan(
          0.14,
        );
      },
    );

    it(
      'should keep barred-spiral arms broad and organic while overlapping the bar-root region',
      () => {
        const target =
          model(
            1n,
          );

        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const profile =
          spiralReinforcementRadialProfile(
            layout,
            target,
            CORE_PARTICLE_COUNT +
              BARRED_SPIRAL_BODY_PARTICLE_COUNT,
            CORE_PARTICLE_COUNT +
              BARRED_SPIRAL_BODY_PARTICLE_COUNT +
              BARRED_SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT,
          );

        expect(
          profile.insideCanonicalStartFraction,
        ).toBeGreaterThan(
          0.01,
        );

        expect(
          profile.innerFraction,
        ).toBeGreaterThan(
          0.40,
        );

        expect(
          profile.outerFraction,
        ).toBeGreaterThan(
          0.10,
        );

        expect(
          profile.outerFraction,
        ).toBeLessThan(
          0.30,
        );

        expect(
          profile.innerFraction,
        ).toBeGreaterThan(
          profile.outerFraction *
          1.5,
        );
      },
    );

    it(
      'should visibly populate both barred-spiral bar ends through the arm-root transition',
      () => {
        const target =
          model(
            1n,
          );

        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const bar =
          target
            .visualStructure
            ?.bar;

        if (
          bar ===
            null ||
          bar ===
            undefined
        ) {
          throw new Error(
            'Bar-end coverage test requires a discovered barred spiral.',
          );
        }

        const start =
          layout.count -
          BAR_PARTICLE_COUNT;

        let positiveEnd =
          0;

        let negativeEnd =
          0;

        const cosine =
          Math.cos(
            bar
              .angleRadians,
          );

        const sine =
          Math.sin(
            bar
              .angleRadians,
          );

        for (
          let particle =
            start;
          particle <
            layout.count;
          particle +=
            1
        ) {
          const x =
            layout.positions[
              particle *
              3
            ];

          const y =
            layout.positions[
              particle *
                3 +
              1
            ];

          const along =
            x *
              cosine +
            y *
              sine;

          if (
            Math.abs(
              along,
            ) >=
            bar
              .halfLengthNormalized *
              0.62
          ) {
            if (
              along <
              0
            ) {
              negativeEnd +=
                1;
            } else {
              positiveEnd +=
                1;
            }
          }
        }

        expect(
          (
            positiveEnd +
            negativeEnd
          ) /
          BAR_PARTICLE_COUNT,
        ).toBeGreaterThan(
          0.28,
        );

        expect(
          positiveEnd /
          BAR_PARTICLE_COUNT,
        ).toBeGreaterThan(
          0.12,
        );

        expect(
          negativeEnd /
          BAR_PARTICLE_COUNT,
        ).toBeGreaterThan(
          0.12,
        );
      },
    );

    it(
      'should curve both barred-spiral bar ends into the arm roots instead of keeping a ruler-straight centerline',
      () => {
        const target =
          model(
            1n,
          );

        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const bar =
          target
            .visualStructure
            ?.bar;

        if (
          bar ===
            null ||
          bar ===
            undefined
        ) {
          throw new Error(
            'Curved bar-transition test requires a discovered barred spiral.',
          );
        }

        const start =
          layout.count -
          BAR_PARTICLE_COUNT;

        const cosine =
          Math.cos(
            bar
              .angleRadians,
          );

        const sine =
          Math.sin(
            bar
              .angleRadians,
          );

        let positiveCount =
          0;

        let negativeCount =
          0;

        let positiveAcross =
          0;

        let negativeAcross =
          0;

        for (
          let particle =
            start;
          particle <
            layout.count;
          particle +=
            1
        ) {
          const x =
            layout.positions[
              particle *
              3
            ];

          const y =
            layout.positions[
              particle *
                3 +
              1
            ];

          const along =
            x *
              cosine +
            y *
              sine;

          if (
            Math.abs(
              along,
            ) <
            bar
              .halfLengthNormalized *
              0.68
          ) {
            continue;
          }

          const across =
            -x *
              sine +
            y *
              cosine;

          if (
            along <
            0
          ) {
            negativeCount +=
              1;

            negativeAcross +=
              across;
          } else {
            positiveCount +=
              1;

            positiveAcross +=
              across;
          }
        }

        expect(
          positiveCount,
        ).toBeGreaterThan(
          400,
        );

        expect(
          negativeCount,
        ).toBeGreaterThan(
          400,
        );

        const positiveMeanAcross =
          positiveAcross /
          positiveCount;

        const negativeMeanAcross =
          negativeAcross /
          negativeCount;

        expect(
          Math.abs(
            positiveMeanAcross,
          ),
        ).toBeGreaterThan(
          bar
            .widthNormalized *
            0.08,
        );

        expect(
          Math.abs(
            negativeMeanAcross,
          ),
        ).toBeGreaterThan(
          bar
            .widthNormalized *
            0.08,
        );
      },
    );

    it(
      'should render BARRED_SPIRAL through a dedicated warm bulge, chromatic disk and volumetric gas population',
      () => {
        const target =
          model(
            1n,
          );

        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              target,
            );

        const gasStart =
          CORE_PARTICLE_COUNT +
          BARRED_SPIRAL_BODY_PARTICLE_COUNT +
          BARRED_SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT;

        let coreRed =
          0;

        let coreBlue =
          0;

        let blueStars =
          0;

        let warmStars =
          0;

        let positiveGasDepth =
          0;

        let negativeGasDepth =
          0;

        let blueGas =
          0;

        let warmGas =
          0;

        for (
          let particle =
            0;
          particle <
            CORE_PARTICLE_COUNT;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const red =
            layout.colors[
              offset
            ];

          const blue =
            layout.colors[
              offset +
                2
            ];

          coreRed +=
            red;

          coreBlue +=
            blue;
        }

        for (
          let particle =
            CORE_PARTICLE_COUNT;
          particle <
            gasStart;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const red =
            layout.colors[
              offset
            ];

          const green =
            layout.colors[
              offset +
                1
            ];

          const blue =
            layout.colors[
              offset +
                2
            ];

          if (
            blue >
              red +
                0.16
          ) {
            blueStars +=
              1;
          }

          if (
            red >
              blue -
                0.02 &&
            red >
              green +
                0.05
          ) {
            warmStars +=
              1;
          }
        }

        for (
          let particle =
            gasStart;
          particle <
            gasStart +
              BARRED_SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const z =
            layout.positions[
              offset +
                2
            ];

          const red =
            layout.colors[
              offset
            ];

          const green =
            layout.colors[
              offset +
                1
            ];

          const blue =
            layout.colors[
              offset +
                2
            ];

          expect(
            layout.sizes[
              particle
            ],
          ).toBeGreaterThanOrEqual(
            9.0,
          );

          expect(
            layout.sizes[
              particle
            ],
          ).toBeLessThanOrEqual(
            15.2,
          );

          if (
            z >
            0.006
          ) {
            positiveGasDepth +=
              1;
          }

          if (
            z <
            -0.006
          ) {
            negativeGasDepth +=
              1;
          }

          if (
            blue >
              red +
                0.12
          ) {
            blueGas +=
              1;
          }

          if (
            red >
              green +
                0.08 &&
            red >
              blue -
                0.02
          ) {
            warmGas +=
              1;
          }
        }

        expect(
          coreRed /
          CORE_PARTICLE_COUNT,
        ).toBeGreaterThan(
          coreBlue /
          CORE_PARTICLE_COUNT +
          0.20,
        );

        expect(
          blueStars,
        ).toBeGreaterThan(
          10_000,
        );

        expect(
          warmStars,
        ).toBeGreaterThan(
          7_000,
        );

        expect(
          positiveGasDepth,
        ).toBeGreaterThan(
          1_000,
        );

        expect(
          negativeGasDepth,
        ).toBeGreaterThan(
          1_000,
        );

        expect(
          blueGas,
        ).toBeGreaterThan(
          1_700,
        );

        expect(
          warmGas,
        ).toBeGreaterThan(
          800,
        );
      },
      30_000,
    );

    it(
      'should rebuild SPIRAL arms as a broad organic stellar population from the inner disk to the outskirts',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                3n,
              ),
            );

        const armStart =
          CORE_PARTICLE_COUNT +
          BODY_PARTICLE_COUNT;

        const armEnd =
          armStart +
          SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT;

        let inner =
          0;

        let outer =
          0;

        for (
          let particle =
            armStart;
          particle <
            armEnd;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const radius =
            Math.hypot(
              layout.positions[
                offset
              ],
              layout.positions[
                offset +
                  1
              ],
            );

          if (
            radius <
            0.38
          ) {
            inner +=
              1;
          }

          if (
            radius >
            0.72
          ) {
            outer +=
              1;
          }
        }

        expect(
          inner,
        ).toBeGreaterThan(
          2_000,
        );

        expect(
          outer,
        ).toBeGreaterThan(
          4_000,
        );
      },
    );

    it(
      'should embed SPIRAL gas as a sparse chromatic 3D volume instead of a planar overlay',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                3n,
              ),
            );

        expect(
          layout.count,
        ).toBe(
          SPIRAL_PARTICLE_COUNT,
        );

        const gasStart =
          CORE_PARTICLE_COUNT +
          BODY_PARTICLE_COUNT +
          SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT;

        let gasCount =
          0;

        let positiveDepth =
          0;

        let negativeDepth =
          0;

        let blueGas =
          0;

        let warmOrMagentaGas =
          0;

        let innerGas =
          0;

        let maxAbsZ =
          0;

        for (
          let particle =
            gasStart;
          particle <
            gasStart +
              SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const x =
            layout.positions[
              offset
            ];

          const y =
            layout.positions[
              offset +
                1
            ];

          const z =
            layout.positions[
              offset +
                2
            ];

          const red =
            layout.colors[
              offset
            ];

          const green =
            layout.colors[
              offset +
                1
            ];

          const blue =
            layout.colors[
              offset +
                2
            ];

          expect(
            layout.sizes[
              particle
            ],
          ).toBeGreaterThanOrEqual(
            9.0,
          );

          expect(
            layout.sizes[
              particle
            ],
          ).toBeLessThanOrEqual(
            15.2,
          );

          gasCount +=
            1;

          if (
            z >
            0.006
          ) {
            positiveDepth +=
              1;
          }

          if (
            z <
            -0.006
          ) {
            negativeDepth +=
              1;
          }

          maxAbsZ =
            Math.max(
              maxAbsZ,
              Math.abs(
                z,
              ),
            );

          if (
            blue >
              red +
                0.12
          ) {
            blueGas +=
              1;
          }

          if (
            red >
              blue -
                0.02 &&
            red >
              green +
                0.08
          ) {
            warmOrMagentaGas +=
              1;
          }

          if (
            Math.hypot(
              x,
              y,
            ) <
            0.48
          ) {
            innerGas +=
              1;
          }
        }

        expect(
          gasCount,
        ).toBe(
          SPIRAL_VOLUMETRIC_GAS_PARTICLE_COUNT,
        );

        expect(
          positiveDepth,
        ).toBeGreaterThan(
          1_800,
        );

        expect(
          negativeDepth,
        ).toBeGreaterThan(
          1_800,
        );

        expect(
          maxAbsZ,
        ).toBeGreaterThan(
          0.026,
        );

        expect(
          blueGas,
        ).toBeGreaterThan(
          2_800,
        );

        expect(
          warmOrMagentaGas,
        ).toBeGreaterThan(
          1_200,
        );

        expect(
          innerGas,
        ).toBeGreaterThan(
          1_800,
        );
      },
      30_000,
    );

    it(
      'should give a normal spiral visibly mixed stellar temperatures and a warm old central bulge',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                3n,
              ),
            );

        let blueStars =
          0;

        let warmStars =
          0;

        let brightStars =
          0;

        const stellarStart =
          CORE_PARTICLE_COUNT;

        const stellarEnd =
          CORE_PARTICLE_COUNT +
          BODY_PARTICLE_COUNT +
          SPIRAL_ARM_REINFORCEMENT_PARTICLE_COUNT;

        for (
          let particle =
            stellarStart;
          particle <
            stellarEnd;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          const red =
            layout.colors[
              offset
            ];

          const green =
            layout.colors[
              offset +
                1
            ];

          const blue =
            layout.colors[
              offset +
                2
            ];

          if (
            blue >
              red +
                0.16
          ) {
            blueStars +=
              1;
          }

          if (
            red >
              blue +
                0.16
          ) {
            warmStars +=
              1;
          }

          if (
            layout.sizes[
              particle
            ] >
            2.8
          ) {
            brightStars +=
              1;
          }
        }

        expect(
          blueStars,
        ).toBeGreaterThan(
          8_000,
        );

        expect(
          warmStars,
        ).toBeGreaterThan(
          2_000,
        );

        expect(
          brightStars,
        ).toBeGreaterThan(
          1_000,
        );

        let coreRed =
          0;

        let coreBlue =
          0;

        for (
          let particle =
            0;
          particle <
            CORE_PARTICLE_COUNT;
          particle +=
            1
        ) {
          const offset =
            particle *
            3;

          coreRed +=
            layout.colors[
              offset
            ];

          coreBlue +=
            layout.colors[
              offset +
                2
            ];
        }

        expect(
          coreRed /
          CORE_PARTICLE_COUNT,
        ).toBeGreaterThan(
          coreBlue /
          CORE_PARTICLE_COUNT +
          0.20,
        );
      },
    );

    it(
      'should keep every generated attribute finite and bounded',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                1n,
              ),
            );

        const positionRange =
          inspectFiniteRange(
            layout.positions,
          );

        const colorRange =
          inspectFiniteRange(
            layout.colors,
          );

        const opacityRange =
          inspectFiniteRange(
            layout.opacities,
          );

        const sizeRange =
          inspectFiniteRange(
            layout.sizes,
          );

        expect(
          positionRange.allFinite,
        ).toBe(
          true,
        );

        expect(
          positionRange.minimum,
        ).toBeGreaterThan(
          -2,
        );

        expect(
          positionRange.maximum,
        ).toBeLessThan(
          2,
        );

        expect(
          colorRange.allFinite,
        ).toBe(
          true,
        );

        expect(
          colorRange.minimum,
        ).toBeGreaterThanOrEqual(
          0,
        );

        expect(
          colorRange.maximum,
        ).toBeLessThanOrEqual(
          1,
        );

        expect(
          opacityRange.allFinite,
        ).toBe(
          true,
        );

        expect(
          opacityRange.minimum,
        ).toBeGreaterThanOrEqual(
          0,
        );

        expect(
          opacityRange.maximum,
        ).toBeLessThanOrEqual(
          1,
        );

        expect(
          sizeRange.allFinite,
        ).toBe(
          true,
        );

        expect(
          sizeRange.minimum,
        ).toBeGreaterThan(
          0,
        );

        expect(
          sizeRange.maximum,
        ).toBeLessThanOrEqual(
          15.2,
        );
      },
    );

    it(
      'should render Caeloria as an expanded volumetric spheroidal cloud instead of a correlated curve',
      () => {
        const layout =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                0n,
              ),
            );

        const bodyStart =
          CORE_PARTICLE_COUNT;

        const bodyEnd =
          CORE_PARTICLE_COUNT +
          BODY_PARTICLE_COUNT;

        const occupiedCells =
          projectedOccupancy(
            layout,
            bodyStart,
            bodyEnd,
            32,
          );

        expect(
          occupiedCells,
        ).toBeGreaterThan(
          0.46,
        );

        const radialReach =
          projectedRadialReach(
            layout,
            bodyStart,
            bodyEnd,
          );

        expect(
          radialReach,
        ).toBeGreaterThan(
          1.02,
        );

        let positiveDepth =
          0;

        let negativeDepth =
          0;

        for (
          let particle =
            bodyStart;
          particle <
            bodyEnd;
          particle +=
            1
        ) {
          const z =
            layout.positions[
              particle *
                3 +
              2
            ];

          if (
            z >
            0.03
          ) {
            positiveDepth +=
              1;
          }

          if (
            z <
            -0.03
          ) {
            negativeDepth +=
              1;
          }
        }

        expect(
          positiveDepth,
        ).toBeGreaterThan(
          BODY_PARTICLE_COUNT *
          0.25,
        );

        expect(
          negativeDepth,
        ).toBeGreaterThan(
          BODY_PARTICLE_COUNT *
          0.25,
        );
      },
    );

    it(
      'should render the dwarf family through a dedicated dense body, warm centre and chromatic gas envelope',
      () => {
        const dwarf =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                4n,
              ),
            );

        expect(
          dwarf.count,
        ).toBe(
          DWARF_PARTICLE_COUNT,
        );

        const bodyStart =
          DWARF_CORE_PARTICLE_COUNT;

        const clumpyBodyEnd =
          DWARF_CORE_PARTICLE_COUNT +
          DWARF_BODY_PARTICLE_COUNT +
          DWARF_CLUSTER_PARTICLE_COUNT;

        const gasStart =
          clumpyBodyEnd;

        const gasEnd =
          gasStart +
          DWARF_GAS_PARTICLE_COUNT;

        const haloStart =
          gasEnd;

        const occupiedCells =
          projectedOccupancy(
            dwarf,
            bodyStart,
            clumpyBodyEnd,
            32,
          );

        expect(
          occupiedCells,
        ).toBeGreaterThan(
          0.36,
        );

        const innerFraction =
          projectedFractionWithinRadius(
            dwarf,
            bodyStart,
            clumpyBodyEnd,
            0.82,
          );

        expect(
          innerFraction,
        ).toBeGreaterThan(
          0.50,
        );

        const reach =
          projectedRadialReach(
            dwarf,
            bodyStart,
            clumpyBodyEnd,
          );

        expect(
          reach,
        ).toBeGreaterThan(
          0.98,
        );

        const brightCentralFraction =
          projectedFractionWithinRadius(
            dwarf,
            0,
            DWARF_CORE_PARTICLE_COUNT,
            0.46,
          );

        expect(
          brightCentralFraction,
        ).toBeGreaterThan(
          0.74,
        );

        expect(
          averageColorChannel(
            dwarf,
            0,
            DWARF_CORE_PARTICLE_COUNT,
            0,
          ),
        ).toBeGreaterThan(
          averageColorChannel(
            dwarf,
            0,
            DWARF_CORE_PARTICLE_COUNT,
            2,
          ),
        );

        expect(
          averageValue(
            dwarf.sizes,
            gasStart,
            gasEnd,
          ),
        ).toBeGreaterThan(
          averageValue(
            dwarf.sizes,
            bodyStart,
            clumpyBodyEnd,
          ) + 2.0,
        );

        const dwarfGasRed =
          averageColorChannel(
            dwarf,
            gasStart,
            gasEnd,
            0,
          );

        const dwarfGasGreen =
          averageColorChannel(
            dwarf,
            gasStart,
            gasEnd,
            1,
          );

        const dwarfGasBlue =
          averageColorChannel(
            dwarf,
            gasStart,
            gasEnd,
            2,
          );

        expect(
          Math.max(
            dwarfGasRed,
            dwarfGasGreen,
            dwarfGasBlue,
          ) - Math.min(
            dwarfGasRed,
            dwarfGasGreen,
            dwarfGasBlue,
          ),
        ).toBeGreaterThan(
          0.05,
        );

        expect(
          projectedRadialReach(
            dwarf,
            gasStart,
            gasEnd,
          ),
        ).toBeGreaterThan(
          1.02,
        );

        expect(
          averageValue(
            dwarf.opacities,
            haloStart,
            DWARF_PARTICLE_COUNT,
          ),
        ).toBeLessThan(
          averageValue(
            dwarf.opacities,
            bodyStart,
            clumpyBodyEnd,
          ),
        );
      },
    );

    it(
      'should vary the dwarf gas palette across deterministic family samples',
      () => {
        const gasStart =
          DWARF_CORE_PARTICLE_COUNT +
          DWARF_BODY_PARTICLE_COUNT +
          DWARF_CLUSTER_PARTICLE_COUNT;

        const gasEnd =
          gasStart +
          DWARF_GAS_PARTICLE_COUNT;

        const gasMeans =
          [4n, 19n, 32n].map(
            (
              galaxyIndex,
            ) => {
              const dwarf =
                GalacticMapParticleLayoutGenerator
                  .generate(
                    model(
                      galaxyIndex,
                    ),
                  );

              const red =
                averageColorChannel(
                  dwarf,
                  gasStart,
                  gasEnd,
                  0,
                );

              const green =
                averageColorChannel(
                  dwarf,
                  gasStart,
                  gasEnd,
                  1,
                );

              const blue =
                averageColorChannel(
                  dwarf,
                  gasStart,
                  gasEnd,
                  2,
                );

              expect(
                Math.max(
                  red,
                  green,
                  blue,
                ) - Math.min(
                  red,
                  green,
                  blue,
                ),
              ).toBeGreaterThan(
                0.05,
              );

              return {
                red,
                green,
                blue,
              };
            },
          );

        const pairwiseDistances = [
          distanceBetweenColorMeans(
            gasMeans[0],
            gasMeans[1],
          ),
          distanceBetweenColorMeans(
            gasMeans[0],
            gasMeans[2],
          ),
          distanceBetweenColorMeans(
            gasMeans[1],
            gasMeans[2],
          ),
        ];

        expect(
          Math.max(
            ...pairwiseDistances,
          ),
        ).toBeGreaterThan(
          0.09,
        );
      },
    );

    it(
      'should render IRREGULAR through a dedicated lopsided body, warm centre, mixed stars and chromatic volumetric gas',
      () => {
        const irregular =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                10n,
              ),
            );

        expect(
          irregular.count,
        ).toBe(
          IRREGULAR_PARTICLE_COUNT,
        );

        const bodyStart =
          IRREGULAR_CORE_PARTICLE_COUNT;

        const stellarBodyEnd =
          IRREGULAR_CORE_PARTICLE_COUNT +
          IRREGULAR_BODY_PARTICLE_COUNT +
          IRREGULAR_CLUSTER_PARTICLE_COUNT;

        const gasStart =
          stellarBodyEnd;

        const gasEnd =
          gasStart +
          IRREGULAR_GAS_PARTICLE_COUNT;

        const occupiedCells =
          projectedOccupancy(
            irregular,
            bodyStart,
            stellarBodyEnd,
            32,
          );

        expect(
          occupiedCells,
        ).toBeGreaterThan(
          0.30,
        );

        const innerFraction =
          projectedFractionWithinRadius(
            irregular,
            bodyStart,
            stellarBodyEnd,
            0.92,
          );

        expect(
          innerFraction,
        ).toBeGreaterThan(
          0.34,
        );

        expect(
          projectedRadialReach(
            irregular,
            bodyStart,
            stellarBodyEnd,
          ),
        ).toBeGreaterThan(
          1.05,
        );

        expect(
          averageColorChannel(
            irregular,
            0,
            IRREGULAR_CORE_PARTICLE_COUNT,
            0,
          ),
        ).toBeGreaterThan(
          averageColorChannel(
            irregular,
            0,
            IRREGULAR_CORE_PARTICLE_COUNT,
            2,
          ),
        );

        const stellarSizeRange =
          inspectFiniteRange(
            irregular.sizes.subarray(
              bodyStart,
              stellarBodyEnd,
            ),
          );

        expect(
          stellarSizeRange.maximum -
          stellarSizeRange.minimum,
        ).toBeGreaterThan(
          2.0,
        );

        const stellarTemperatureFractions =
          colorTemperatureFractions(
            irregular,
            bodyStart,
            stellarBodyEnd,
          );

        expect(
          stellarTemperatureFractions.blueBiased,
        ).toBeGreaterThan(
          0.08,
        );

        expect(
          stellarTemperatureFractions.warmBiased,
        ).toBeGreaterThan(
          0.08,
        );

        const gasRed =
          averageColorChannel(
            irregular,
            gasStart,
            gasEnd,
            0,
          );

        const gasGreen =
          averageColorChannel(
            irregular,
            gasStart,
            gasEnd,
            1,
          );

        const gasBlue =
          averageColorChannel(
            irregular,
            gasStart,
            gasEnd,
            2,
          );

        expect(
          Math.max(
            gasRed,
            gasGreen,
            gasBlue,
          ) - Math.min(
            gasRed,
            gasGreen,
            gasBlue,
          ),
        ).toBeGreaterThan(
          0.06,
        );

        expect(
          averageValue(
            irregular.sizes,
            gasStart,
            gasEnd,
          ),
        ).toBeGreaterThan(
          averageValue(
            irregular.sizes,
            bodyStart,
            stellarBodyEnd,
          ) + 2.0,
        );

        expect(
          projectedRadialReach(
            irregular,
            gasStart,
            gasEnd,
          ),
        ).toBeGreaterThan(
          1.10,
        );
      },
    );

    it(
      'should vary the IRREGULAR gas palette across deterministic renderer identities without changing morphology routing',
      () => {
        const baseInput =
          createGalacticMapParticleRenderInput(
            model(
              10n,
            ),
          );

        const gasStart =
          IRREGULAR_CORE_PARTICLE_COUNT +
          IRREGULAR_BODY_PARTICLE_COUNT +
          IRREGULAR_CLUSTER_PARTICLE_COUNT;

        const gasEnd =
          gasStart +
          IRREGULAR_GAS_PARTICLE_COUNT;

        const gasMeans =
          ['10', '1010', '3010'].map(
            galaxyIndex => {
              const layout =
                GalacticMapParticleLayoutGenerator
                  .generateFromRenderInput(
                    Object.freeze({
                      ...baseInput,
                      galaxyIndex,
                    }),
                  );

              expect(
                layout.count,
              ).toBe(
                IRREGULAR_PARTICLE_COUNT,
              );

              return {
                red:
                  averageColorChannel(
                    layout,
                    gasStart,
                    gasEnd,
                    0,
                  ),

                green:
                  averageColorChannel(
                    layout,
                    gasStart,
                    gasEnd,
                    1,
                  ),

                blue:
                  averageColorChannel(
                    layout,
                    gasStart,
                    gasEnd,
                    2,
                  ),
              };
            },
          );

        const pairwiseDistances = [
          distanceBetweenColorMeans(
            gasMeans[0],
            gasMeans[1],
          ),
          distanceBetweenColorMeans(
            gasMeans[0],
            gasMeans[2],
          ),
          distanceBetweenColorMeans(
            gasMeans[1],
            gasMeans[2],
          ),
        ];

        expect(
          Math.max(
            ...pairwiseDistances,
          ),
        ).toBeGreaterThan(
          0.12,
        );
      },
    );

    it(
      'should keep a discovered spiral disk substantially thinner than the spheroidal body',
      () => {
        const spheroidal =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                0n,
              ),
            );

        const spiral =
          GalacticMapParticleLayoutGenerator
            .generate(
              model(
                3n,
              ),
            );

        const spheroidalDepth =
          bodyDepthRms(
            spheroidal,
          );

        const spiralDepth =
          bodyDepthRms(
            spiral,
          );

        expect(
          spiralDepth,
        ).toBeLessThan(
          spheroidalDepth *
          0.45,
        );
      },
    );
  },
);

interface FiniteRange {
  readonly allFinite:
    boolean;

  readonly minimum:
    number;

  readonly maximum:
    number;
}

function inspectFiniteRange(
  values:
    Float32Array,
): FiniteRange {

  let allFinite =
    true;

  let minimum =
    Number.POSITIVE_INFINITY;

  let maximum =
    Number.NEGATIVE_INFINITY;

  for (
    let index =
      0;
    index <
      values.length;
    index +=
      1
  ) {
    const value =
      values[
        index
      ];

    if (
      !Number.isFinite(
        value,
      )
    ) {
      allFinite =
        false;

      continue;
    }

    if (
      value <
      minimum
    ) {
      minimum =
        value;
    }

    if (
      value >
      maximum
    ) {
      maximum =
        value;
    }
  }

  return {
    allFinite,
    minimum,
    maximum,
  };
}

function colorTemperatureFractions(
  layout:
    GalacticMapParticleLayout,

  start:
    number,

  end:
    number,
): Readonly<{
  blueBiased: number;
  warmBiased: number;
}> {

  let blueBiased =
    0;

  let warmBiased =
    0;

  for (
    let particle = start;
    particle < end;
    particle += 1
  ) {
    const colorOffset =
      particle * 3;

    const red =
      layout.colors[
        colorOffset
      ];

    const blue =
      layout.colors[
        colorOffset + 2
      ];

    if (
      blue > red + 0.07
    ) {
      blueBiased += 1;
    }

    if (
      red > blue + 0.07
    ) {
      warmBiased += 1;
    }
  }

  const count =
    Math.max(
      1,
      end - start,
    );

  return Object.freeze({
    blueBiased:
      blueBiased / count,

    warmBiased:
      warmBiased / count,
  });
}

function distanceBetweenColorMeans(
  first:
    {
      readonly red:
        number;

      readonly green:
        number;

      readonly blue:
        number;
    },

  second:
    {
      readonly red:
        number;

      readonly green:
        number;

      readonly blue:
        number;
    },
): number {

  return Math.hypot(
    first.red - second.red,
    first.green - second.green,
    first.blue - second.blue,
  );
}

function averageValue(
  values:
    Float32Array,

  start:
    number,

  end:
    number,
): number {

  let total =
    0;

  for (
    let index =
      start;
    index <
      end;
    index +=
      1
  ) {
    total +=
      values[index];
  }

  return total /
    Math.max(
      1,
      end -
        start,
    );
}

function averageColorChannel(
  layout:
    GalacticMapParticleLayout,

  start:
    number,

  end:
    number,

  channel:
    number,
): number {

  let total =
    0;

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    total +=
      layout.colors[
        particle *
          3 +
        channel
      ];
  }

  return total /
    Math.max(
      1,
      end -
        start,
    );
}

function projectedOccupancy(
  layout:
    GalacticMapParticleLayout,

  start:
    number,

  end:
    number,

  bins:
    number,
): number {

  const occupied =
    new Set<string>();

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    const x =
      layout.positions[
        particle *
        3
      ];

    const y =
      layout.positions[
        particle *
          3 +
        1
      ];

    const xBin =
      Math.floor(
        (
          x +
          1.2
        ) /
        2.4 *
        bins,
      );

    const yBin =
      Math.floor(
        (
          y +
          1.2
        ) /
        2.4 *
        bins,
      );

    if (
      xBin >=
        0 &&
      xBin <
        bins &&
      yBin >=
        0 &&
      yBin <
        bins
    ) {
      occupied.add(
        `${xBin}:${yBin}`,
      );
    }
  }

  return occupied.size /
    (
      bins *
      bins
    );
}

function projectedRadialReach(
  layout:
    GalacticMapParticleLayout,

  start:
    number,

  end:
    number,
): number {

  let maximum =
    0;

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    const x =
      layout.positions[
        particle *
        3
      ];

    const y =
      layout.positions[
        particle *
          3 +
        1
      ];

    maximum =
      Math.max(
        maximum,
        Math.hypot(
          x,
          y,
        ),
      );
  }

  return maximum;
}

function projectedFractionWithinRadius(
  layout:
    GalacticMapParticleLayout,

  start:
    number,

  end:
    number,

  radius:
    number,
): number {

  let inside =
    0;

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    const x =
      layout.positions[
        particle *
        3
      ];

    const y =
      layout.positions[
        particle *
          3 +
        1
      ];

    if (
      Math.hypot(
        x,
        y,
      ) <=
      radius
    ) {
      inside +=
        1;
    }
  }

  return inside /
    Math.max(
      1,
      end -
        start,
    );
}

interface SpiralReinforcementRadialProfile {
  readonly insideCanonicalStartFraction:
    number;

  readonly innerFraction:
    number;

  readonly outerFraction:
    number;
}

function spiralReinforcementRadialProfile(
  layout:
    GalacticMapParticleLayout,

  model:
    GalacticMapModel,

  start:
    number,

  end:
    number,
): SpiralReinforcementRadialProfile {

  const visual =
    model.visualStructure;

  if (
    visual ===
      null ||
    visual.arms.length ===
      0
  ) {
    throw new Error(
      'Spiral reinforcement profile requires a discovered galaxy with visual arms.',
    );
  }

  const radialStart =
    Math.min(
      ...visual.arms.map(
        arm =>
          arm.radialStartNormalized,
      ),
    );

  const radialEnd =
    Math.max(
      ...visual.arms.map(
        arm =>
          arm.radialEndNormalized,
      ),
    );

  const radialSpan =
    Math.max(
      1e-9,
      radialEnd -
        radialStart,
    );

  const innerLimit =
    radialStart +
    radialSpan *
      0.48;

  const outerLimit =
    radialStart +
    radialSpan *
      0.78;

  let insideCanonicalStart =
    0;

  let inner =
    0;

  let outer =
    0;

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    const x =
      layout.positions[
        particle *
        3
      ];

    const y =
      layout.positions[
        particle *
          3 +
        1
      ];

    const radius =
      Math.hypot(
        x,
        y,
      );

    if (
      radius <
      radialStart
    ) {
      insideCanonicalStart +=
        1;
    }

    if (
      radius <=
      innerLimit
    ) {
      inner +=
        1;
    }

    if (
      radius >=
      outerLimit
    ) {
      outer +=
        1;
    }
  }

  const count =
    Math.max(
      1,
      end -
        start,
    );

  return {
    insideCanonicalStartFraction:
      insideCanonicalStart /
      count,

    innerFraction:
      inner /
      count,

    outerFraction:
      outer /
      count,
  };
}

function bodyDepthRms(
  layout:
    GalacticMapParticleLayout,
): number {

  let squared =
    0;

  const start =
    CORE_PARTICLE_COUNT;

  const end =
    CORE_PARTICLE_COUNT +
    BODY_PARTICLE_COUNT;

  for (
    let particle =
      start;
    particle <
      end;
    particle +=
      1
  ) {
    const z =
      layout.positions[
        particle *
          3 +
        2
      ];

    squared +=
      z *
      z;
  }

  return Math.sqrt(
    squared /
    BODY_PARTICLE_COUNT,
  );
}
