/**
 * 29.1E-H4: explicitly conditional atmospheric survival/cryochemistry bridge.
 *
 * A phase-20 atmosphere generated for the PROGENITOR is an inventory proxy,
 * NEVER the contemporary atmosphere of an evolved white-dwarf planet.
 *
 * We do not know the RGB/AGB radius, time-resolved XUV exposure, stellar wind,
 * magnetosphere, volatile replenishment or the present-day companion geometry.
 * Therefore survival has a physical lower limit of zero. This module computes
 * a *no-replenishment, WD-only* gas pressure ceiling after cryocondensation,
 * not an actual present-day pressure, composition, climate or proof of survival.
 * No seeded RNG, persisted aggregate, wall clock or mutable cache is used.
 */
export interface PreAgbGasInventoryProxy {
  readonly gas: string;
  readonly moleFraction01: number;
}

export interface ConditionalGasCeiling {
  readonly gas: string;
  readonly gasPressureCeilingPascal: number;
  readonly gasFractionWithinCeiling01: number;
  readonly cryocondensationLimited: boolean;
}

export interface PostAgbAtmosphereScenario {
  readonly kind: 'WD_ONLY_NO_REPLENISHMENT';
  readonly progenitorReferencePressurePascal: number;
  /** The unknown RGB/AGB escape history permits complete atmospheric loss. */
  readonly possiblePressureMinimumPascal: 0;
  /** Only a ceiling for the specifically defined WD-only, no-replenishment scenario. */
  readonly scenarioGasPressureCeilingPascal: number;
  readonly equilibriumTemperatureReferenceKelvin: number;
  readonly greenhouseTemperatureCeilingKelvin: number;
  readonly greenhouseWarmingCeilingKelvin: number;
  readonly coolingAgeBillionYears: number;
  readonly escapeVelocityKilometersPerSecond: number;
  readonly gasCeilings: readonly ConditionalGasCeiling[];
  readonly volatileGasesWithCryogenicCondensation: readonly string[];
  readonly companionIrradiationUnresolved: boolean;
  readonly survivalUnresolved: true;
  readonly currentPressureUnresolved: true;
  readonly currentWaterUnresolved: true;
}

export interface PostAgbAtmosphereScenarioInput {
  readonly isWhiteDwarf: boolean;
  readonly postAgbOrbitHypothesisAvailable: boolean;
  readonly progenitorReferencePressurePascal: number | null;
  readonly progenitorGasComposition: readonly PreAgbGasInventoryProxy[];
  readonly massEarth: number;
  readonly radiusEarth: number;
  readonly coolingAgeBillionYears: number | null;
  /** H3 airless lower-temperature scenario; NOT an observational temperature. */
  readonly airlessReferenceTemperatureKelvin: number | null;
  readonly companionIrradiationUnresolved: boolean;
}

// Reference T where vapour pressure is approximately 1 atmosphere, together
// with a first-order sublimation/vaporization enthalpy (J/mol). These are
// intentionally rough order-of-magnitude anchors, not a phase-equilibrium EOS.
// For <~0.5 Tref use an effectively condensed regime rather than extrapolating
// Clausius–Clapeyron arbitrarily far outside its physical validity.
const VOLATILE_REFERENCE = Object.freeze({
  NITROGEN: [77.36, 5600], OXYGEN: [90.2, 6800],
  CARBON_DIOXIDE: [194.7, 25200], WATER_VAPOR: [273.15, 51000],
  METHANE: [111.7, 8200], ARGON: [87.3, 6400],
  SULFUR_DIOXIDE: [263, 26000], CARBON_MONOXIDE: [81.6, 6000],
  AMMONIA: [239.8, 23000], HYDROGEN: [20.28, 900],
  HELIUM: [4.22, 80],
} as const);
const MOLAR_MASS_KG = Object.freeze({
  HYDROGEN: 0.00201588, HELIUM: 0.004002602,
  NITROGEN: 0.0280134, OXYGEN: 0.0319988,
  CARBON_DIOXIDE: 0.0440095, WATER_VAPOR: 0.01801528,
  METHANE: 0.0160425, ARGON: 0.039948,
  SULFUR_DIOXIDE: 0.064066, CARBON_MONOXIDE: 0.0280101,
  AMMONIA: 0.01703052,
} as const);
const R = 8.314462618;
const G = 6.67430e-11;
const M_EARTH = 5.9722e24;
const R_EARTH = 6371000;
const BOLTZMANN = 1.380649e-23;
const AVOGADRO = 6.02214076e23;
const ATM_PASCAL = 101325;

function gasReference(gas: string): readonly [number, number] | null {
  return Object.prototype.hasOwnProperty.call(VOLATILE_REFERENCE, gas)
    ? VOLATILE_REFERENCE[gas as keyof typeof VOLATILE_REFERENCE]
    : null;
}

function gasMolarMass(gas: string): number | null {
  return Object.prototype.hasOwnProperty.call(MOLAR_MASS_KG, gas)
    ? MOLAR_MASS_KG[gas as keyof typeof MOLAR_MASS_KG]
    : null;
}

export function cryogenicPressureCeiling(gas: string, kelvin: number): number | null {
  const reference = gasReference(gas);
  if (reference === null) return null;
  const [boilingReferenceKelvin, enthalpy] = reference;
  if (kelvin >= boilingReferenceKelvin) return Infinity;
  // Below half the reference temperature, do NOT extrapolate the pressure
  // equation into an uncalibrated regime. Instead use its value at Tref/2 as
  // a deliberately loose, conservative scenario gas ceiling (not Psat).
  const boundedTemperature = Math.max(kelvin, boilingReferenceKelvin * 0.5);
  return ATM_PASCAL * Math.exp((-enthalpy / R) *
    (1 / boundedTemperature - 1 / boilingReferenceKelvin));
}

/** Returns null unless every gas can be meaningfully bounded by this model. */
export function projectWhiteDwarfPostAgbAtmosphereScenario(
  input: PostAgbAtmosphereScenarioInput,
): PostAgbAtmosphereScenario | null {
  if (!input.isWhiteDwarf || !input.postAgbOrbitHypothesisAvailable) return null;
  const {progenitorReferencePressurePascal: pressure,
    progenitorGasComposition: composition, massEarth: mass,
    radiusEarth: radius, coolingAgeBillionYears: age,
    airlessReferenceTemperatureKelvin: temp} = input;
  if (pressure === null || age === null || temp === null || !Number.isFinite(pressure) ||
      pressure < 0 || !Number.isFinite(mass) || mass <= 0 ||
      !Number.isFinite(radius) || radius <= 0 ||
      !Number.isFinite(age) || age < 0 || age > 14 ||
      !Number.isFinite(temp) || temp < 2.7 || temp > 2500 ||
      composition.length === 0) return null;
  const total = composition.reduce((acc, entry) => acc + entry.moleFraction01, 0);
  if (!Number.isFinite(total) || total <= 0 || composition.some(entry =>
    !Number.isFinite(entry.moleFraction01) || entry.moleFraction01 < 0 ||
    gasReference(entry.gas) === null || gasMolarMass(entry.gas) === null)) return null;

  const escapeVelocity = Math.sqrt(2 * G * M_EARTH * mass / (R_EARTH * radius)) / 1000;
  const gasBounds: {gas: string; partial: number; limited: boolean}[] = [];
  const condensed: string[] = [];
  // The WD-only airless equilibrium temperature is not necessarily the
  // atmospheric surface temperature. It is just this scenario's boundary.
  for (const entry of composition) {
    const sourcePartial = pressure * entry.moleFraction01 / total;
    const molarMass = gasMolarMass(entry.gas)!;
    const moleculeMass = molarMass / AVOGADRO;
    const lambda = G * M_EARTH * mass * moleculeMass /
      (R_EARTH * radius * BOLTZMANN * temp);
    const pressureCeiling = cryogenicPressureCeiling(entry.gas, temp);
    const liquidSolidLimited = pressureCeiling !== null && pressureCeiling < sourcePartial;
    const partial = lambda < 10 ? 0 : Math.min(sourcePartial, pressureCeiling ?? sourcePartial);
    if (liquidSolidLimited) condensed.push(entry.gas);
    gasBounds.push({gas: entry.gas, partial, limited: liquidSolidLimited});
  }
  const gasUpper = gasBounds.reduce((acc, gas) => acc + gas.partial, 0);
  if (!Number.isFinite(gasUpper)) return null;
  const gasCeilings = Object.freeze(gasBounds.map(gas => Object.freeze({
    gas: gas.gas,
    gasPressureCeilingPascal: gas.partial,
    gasFractionWithinCeiling01: gasUpper > 0 ? gas.partial / gasUpper : 0,
    cryocondensationLimited: gas.limited,
  })));
  // Optical-depth upper proxy for this no-replenishment scenario only. It is
  // not a spectroscopic greenhouse calculation. Bound tau <= 10 to avoid
  // claiming arbitrarily large feedback with an unknown atmosphere.
  const greenhouseWeight: Record<string, number> = {
    CARBON_DIOXIDE: 1.5, WATER_VAPOR: 2, METHANE: 1,
    AMMONIA: 1.2, SULFUR_DIOXIDE: 1, HYDROGEN: 0.05,
  };
  const tau = Math.min(10, gasBounds.reduce((acc, gas) =>
    acc + Math.min(gas.partial / ATM_PASCAL, 10) * (greenhouseWeight[gas.gas] ?? 0), 0));
  const surfaceCeiling = temp * (1 + 0.75 * tau) ** 0.25;
  return Object.freeze({
    kind: 'WD_ONLY_NO_REPLENISHMENT' as const,
    progenitorReferencePressurePascal: pressure,
    possiblePressureMinimumPascal: 0 as const,
    scenarioGasPressureCeilingPascal: gasUpper,
    equilibriumTemperatureReferenceKelvin: temp,
    greenhouseTemperatureCeilingKelvin: surfaceCeiling,
    greenhouseWarmingCeilingKelvin: surfaceCeiling - temp,
    coolingAgeBillionYears: age,
    escapeVelocityKilometersPerSecond: escapeVelocity,
    gasCeilings,
    volatileGasesWithCryogenicCondensation: Object.freeze(condensed),
    companionIrradiationUnresolved: input.companionIrradiationUnresolved,
    survivalUnresolved: true as const,
    currentPressureUnresolved: true as const,
    currentWaterUnresolved: true as const,
  });
}
